import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Orbit, i as Pause, n as RotateCcw, o as Eye, r as Play, s as EyeOff } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-5RiLYydW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function orbitSpeed(periodYears) {
	return Math.PI * 2 / (32 * periodYears);
}
/** Visual spin: keep rotations readable rather than 1:1 with the clock. */
function spinSpeed(spinDays) {
	const seconds = THREE_DAY_SECONDS * Math.sqrt(Math.max(Math.abs(spinDays), .4));
	return (spinDays < 0 ? -1 : 1) * Math.PI * 2 / seconds;
}
/** One “visual day” baseline at 1×. */
var THREE_DAY_SECONDS = 11;
var DEG = Math.PI / 180;
var BODIES = [
	{
		id: "sun",
		name: "Sun",
		kind: "star",
		radius: 5.1,
		distance: 0,
		periodYears: 0,
		spinDays: 25,
		inclination: 0,
		tilt: 7.25 * DEG,
		phase: 0,
		swatch: "#ffd089",
		tagline: "G-type main-sequence star",
		blurb: "The gravitational heart of the system. A 4.6-billion-year furnace of hydrogen fusion that holds every planet on its path and paints the inner worlds with light.",
		facts: [
			{
				label: "Type",
				value: "G2V yellow dwarf"
			},
			{
				label: "Diameter",
				value: "1,392,700 km"
			},
			{
				label: "Mass",
				value: "99.86% of the system"
			},
			{
				label: "Surface",
				value: "5,500 °C photosphere"
			},
			{
				label: "Age",
				value: "4.6 billion years"
			}
		]
	},
	{
		id: "mercury",
		name: "Mercury",
		kind: "terrestrial",
		radius: .38,
		distance: 10.2,
		periodYears: .241,
		spinDays: 58.6,
		inclination: 7 * DEG,
		tilt: .03 * DEG,
		phase: .7,
		swatch: "#b7a48a",
		tagline: "Innermost terrestrial",
		blurb: "A cratered, airless rock that bakes at noon and freezes at night. Mercury skims the Sun so closely that a year there lasts only 88 Earth days.",
		facts: [
			{
				label: "Distance",
				value: "0.39 AU"
			},
			{
				label: "Year",
				value: "88 Earth days"
			},
			{
				label: "Day",
				value: "59 Earth days"
			},
			{
				label: "Diameter",
				value: "4,879 km"
			},
			{
				label: "Moons",
				value: "None"
			}
		]
	},
	{
		id: "venus",
		name: "Venus",
		kind: "terrestrial",
		radius: .95,
		distance: 14.6,
		periodYears: .615,
		spinDays: -243,
		inclination: 3.4 * DEG,
		tilt: 177.4 * DEG,
		phase: 2.1,
		swatch: "#e6d2a8",
		atmosphere: "#efe0b8",
		hasClouds: true,
		tagline: "Veiled twin of Earth",
		blurb: "Earth’s size-twin wrapped in a crushing carbon-dioxide shroud. The surface is hotter than Mercury’s, and the planet spins backwards — a day longer than its year.",
		facts: [
			{
				label: "Distance",
				value: "0.72 AU"
			},
			{
				label: "Year",
				value: "225 Earth days"
			},
			{
				label: "Day",
				value: "243 Earth days, retrograde"
			},
			{
				label: "Diameter",
				value: "12,104 km"
			},
			{
				label: "Atmosphere",
				value: "96% CO₂, runaway greenhouse"
			}
		]
	},
	{
		id: "earth",
		name: "Earth",
		kind: "terrestrial",
		radius: 1,
		distance: 19.4,
		periodYears: 1,
		spinDays: 1,
		inclination: 0,
		tilt: 23.4 * DEG,
		phase: .35,
		swatch: "#7eb3e0",
		atmosphere: "#7ec8ff",
		hasClouds: true,
		tagline: "The living world",
		blurb: "The only world known to carry oceans of liquid water and a biosphere. A 23-degree tilt gives us seasons; one moon tugs the tides and steadies the axis.",
		facts: [
			{
				label: "Distance",
				value: "1.00 AU"
			},
			{
				label: "Year",
				value: "365.25 days"
			},
			{
				label: "Day",
				value: "23 h 56 m"
			},
			{
				label: "Diameter",
				value: "12,742 km"
			},
			{
				label: "Moons",
				value: "1 — Luna"
			}
		]
	},
	{
		id: "moon",
		name: "Moon",
		kind: "moon",
		parent: "earth",
		radius: .27,
		distance: 2.55,
		periodYears: .0748,
		spinDays: 27.3,
		inclination: 5.1 * DEG,
		tilt: 6.7 * DEG,
		phase: 1.4,
		swatch: "#c9c4b8",
		tagline: "Earth’s companion",
		blurb: "A tidally locked satellite of anorthosite highlands and dark maria. It is large for a moon — enough to ring Earth with tides and keep our seasons from wandering.",
		facts: [
			{
				label: "Distance",
				value: "384,400 km from Earth"
			},
			{
				label: "Month",
				value: "27.3 days"
			},
			{
				label: "Day",
				value: "Tidally locked"
			},
			{
				label: "Diameter",
				value: "3,474 km"
			},
			{
				label: "Origin",
				value: "Giant impact remnant"
			}
		]
	},
	{
		id: "mars",
		name: "Mars",
		kind: "terrestrial",
		radius: .53,
		distance: 24.6,
		periodYears: 1.881,
		spinDays: 1.03,
		inclination: 1.85 * DEG,
		tilt: 25.2 * DEG,
		phase: 4.2,
		swatch: "#d9896a",
		atmosphere: "#e0a080",
		tagline: "The rusted frontier",
		blurb: "A cold desert stained with iron oxide, carved by ancient rivers and crowned with ice. Olympus Mons and Valles Marineris still dwarf anything on Earth.",
		facts: [
			{
				label: "Distance",
				value: "1.52 AU"
			},
			{
				label: "Year",
				value: "687 Earth days"
			},
			{
				label: "Day",
				value: "24 h 37 m"
			},
			{
				label: "Diameter",
				value: "6,779 km"
			},
			{
				label: "Moons",
				value: "2 — Phobos & Deimos"
			}
		]
	},
	{
		id: "jupiter",
		name: "Jupiter",
		kind: "gas-giant",
		radius: 2.85,
		distance: 38.4,
		periodYears: 11.86,
		spinDays: .41,
		inclination: 1.3 * DEG,
		tilt: 3.1 * DEG,
		phase: 5.6,
		swatch: "#d9b48a",
		atmosphere: "#e8c9a0",
		tagline: "King of the giants",
		blurb: "A failed star of hydrogen and helium, banded by jet streams and stamped with the Great Red Spot — a storm older than any nation on Earth.",
		facts: [
			{
				label: "Distance",
				value: "5.20 AU"
			},
			{
				label: "Year",
				value: "11.9 Earth years"
			},
			{
				label: "Day",
				value: "9 h 56 m"
			},
			{
				label: "Diameter",
				value: "139,820 km"
			},
			{
				label: "Moons",
				value: "95+"
			}
		]
	},
	{
		id: "saturn",
		name: "Saturn",
		kind: "gas-giant",
		radius: 2.38,
		distance: 51.2,
		periodYears: 29.46,
		spinDays: .45,
		inclination: 2.49 * DEG,
		tilt: 26.7 * DEG,
		phase: 1.1,
		swatch: "#e6d7b0",
		atmosphere: "#f0e4c4",
		hasRings: true,
		tagline: "The ringed giant",
		blurb: "A pale gold world so light it would float on water, wearing the solar system’s most famous rings — ice and dust shepherded into knife-thin sheets.",
		facts: [
			{
				label: "Distance",
				value: "9.58 AU"
			},
			{
				label: "Year",
				value: "29.5 Earth years"
			},
			{
				label: "Day",
				value: "10 h 33 m"
			},
			{
				label: "Diameter",
				value: "116,460 km"
			},
			{
				label: "Rings",
				value: "Ice-rich, ~280,000 km across"
			}
		]
	},
	{
		id: "uranus",
		name: "Uranus",
		kind: "ice-giant",
		radius: 1.52,
		distance: 64.8,
		periodYears: 84.01,
		spinDays: -.72,
		inclination: .77 * DEG,
		tilt: 97.8 * DEG,
		phase: 3.3,
		swatch: "#9fd4d8",
		atmosphere: "#b7ecec",
		tagline: "The sideways ice giant",
		blurb: "A pale cyan ball of water, ammonia, and methane ices, knocked onto its side. It rolls around the Sun like a barrel, poles taking turns in decades of daylight.",
		facts: [
			{
				label: "Distance",
				value: "19.2 AU"
			},
			{
				label: "Year",
				value: "84 Earth years"
			},
			{
				label: "Day",
				value: "17 h 14 m, retrograde"
			},
			{
				label: "Diameter",
				value: "50,724 km"
			},
			{
				label: "Tilt",
				value: "98° — seasons last 21 years"
			}
		]
	},
	{
		id: "neptune",
		name: "Neptune",
		kind: "ice-giant",
		radius: 1.46,
		distance: 77.6,
		periodYears: 164.8,
		spinDays: .67,
		inclination: 1.77 * DEG,
		tilt: 28.3 * DEG,
		phase: .2,
		swatch: "#5b82d6",
		atmosphere: "#6f9cff",
		tagline: "The outer wind",
		blurb: "The last true planet, a deep cobalt ice giant with the fastest winds in the system. It was predicted by mathematics before anyone saw it through a telescope.",
		facts: [
			{
				label: "Distance",
				value: "30.1 AU"
			},
			{
				label: "Year",
				value: "165 Earth years"
			},
			{
				label: "Day",
				value: "16 h 6 m"
			},
			{
				label: "Diameter",
				value: "49,244 km"
			},
			{
				label: "Winds",
				value: "Up to 2,000 km/h"
			}
		]
	}
];
var BODY_BY_ID = Object.fromEntries(BODIES.map((b) => [b.id, b]));
var PRIMARY_BODIES = BODIES.filter((b) => b.id !== "moon");
function orbitRadiansPerSecond(body) {
	if (body.periodYears <= 0) return 0;
	return orbitSpeed(body.periodYears);
}
function spinRadiansPerSecond(body) {
	if (body.id === "sun") return Math.PI * 2 / 80;
	return spinSpeed(body.spinDays);
}
function kindLabel(kind) {
	switch (kind) {
		case "star": return "Star";
		case "terrestrial": return "Terrestrial planet";
		case "gas-giant": return "Gas giant";
		case "ice-giant": return "Ice giant";
		case "moon": return "Natural satellite";
	}
}
var SPEED_MIN = .25;
var useSolarStore = create()((set) => ({
	paused: false,
	speed: 1,
	focusedId: "system",
	showLabels: true,
	showTrails: true,
	years: 0,
	setPaused: (paused) => set({ paused }),
	togglePaused: () => set((s) => ({ paused: !s.paused })),
	setSpeed: (speed) => set({ speed: Math.min(24, Math.max(SPEED_MIN, speed)) }),
	setFocused: (focusedId) => set({ focusedId }),
	toggleLabels: () => set((s) => ({ showLabels: !s.showLabels })),
	toggleTrails: () => set((s) => ({ showTrails: !s.showTrails })),
	setYears: (years) => set({ years })
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:enabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-fg text-bg shadow-border hover:bg-fg/90",
			secondary: "bg-surface-2 text-fg shadow-border hover:bg-surface-3",
			ghost: "text-muted hover:bg-surface-2 hover:text-fg",
			outline: "bg-transparent text-fg shadow-border hover:bg-surface-2"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-surface-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-fg/80" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-fg shadow-border transition-[box-shadow,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
}));
Slider.displayName = Slider$1.displayName;
function speedToT(speed) {
	return Math.log(speed / SPEED_MIN) / Math.log(24 / SPEED_MIN);
}
function tToSpeed(t) {
	return SPEED_MIN * Math.pow(24 / SPEED_MIN, t);
}
function formatSpeed(speed) {
	if (speed >= 10) return `${Math.round(speed)}×`;
	if (speed >= 1) return `${speed.toFixed(1)}×`;
	return `${speed.toFixed(2)}×`;
}
function formatYears(years) {
	if (years < 10) return years.toFixed(2);
	if (years < 100) return years.toFixed(1);
	return years.toFixed(0);
}
function Hud() {
	const paused = useSolarStore((s) => s.paused);
	const speed = useSolarStore((s) => s.speed);
	const focusedId = useSolarStore((s) => s.focusedId);
	const showLabels = useSolarStore((s) => s.showLabels);
	const showTrails = useSolarStore((s) => s.showTrails);
	const years = useSolarStore((s) => s.years);
	const togglePaused = useSolarStore((s) => s.togglePaused);
	const setSpeed = useSolarStore((s) => s.setSpeed);
	const setFocused = useSolarStore((s) => s.setFocused);
	const toggleLabels = useSolarStore((s) => s.toggleLabels);
	const toggleTrails = useSolarStore((s) => s.toggleTrails);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.code === "Space") {
				e.preventDefault();
				togglePaused();
			} else if (e.code === "Escape") setFocused("system");
			else if (e.key === "l" || e.key === "L") toggleLabels();
			else if (e.key === "t" || e.key === "T") toggleTrails();
			else if (e.key === "=" || e.key === "+") setSpeed(speed * 1.25);
			else if (e.key === "-" || e.key === "_") setSpeed(speed / 1.25);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		speed,
		setFocused,
		setSpeed,
		toggleLabels,
		togglePaused,
		toggleTrails
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute top-4 right-4 flex items-center gap-1.5 sm:top-6 sm:right-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden md:inline-flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconToggle, {
						pressed: showLabels,
						onPressed: toggleLabels,
						label: showLabels ? "Hide labels" : "Show labels",
						children: showLabels ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconToggle, {
					pressed: showTrails,
					onPressed: toggleTrails,
					label: showTrails ? "Hide orbits" : "Show orbits",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orbit, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopNavigator, {
				focusedId,
				onFocus: setFocused
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, { focusedId }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute inset-x-3 bottom-3 flex flex-col gap-2 md:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileInfo, { focusedId }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileChips, {
						focusedId,
						onFocus: setFocused
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {
						paused,
						speed,
						years,
						focusedId,
						onTogglePaused: togglePaused,
						onSpeed: setSpeed,
						onOverview: () => setFocused("system")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-x-6 bottom-5 hidden md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {
					paused,
					speed,
					years,
					focusedId,
					onTogglePaused: togglePaused,
					onSpeed: setSpeed,
					onOverview: () => setFocused("system")
				})
			})
		]
	});
}
function Wordmark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute top-4 left-4 pr-24 sm:top-6 sm:left-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl leading-none tracking-tight text-fg sm:text-3xl",
			children: "Orrery"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1.5 max-w-[16rem] font-body text-[11px] leading-snug tracking-[0.22em] text-muted uppercase",
			children: "A kinetic model of the solar system"
		})]
	});
}
function IconToggle({ pressed, onPressed, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "secondary",
		size: "icon-sm",
		"aria-pressed": pressed,
		"aria-label": label,
		title: label,
		onClick: onPressed,
		className: cn("size-11 shadow-border", pressed ? "text-fg" : "text-muted"),
		children
	});
}
function DesktopNavigator({ focusedId, onFocus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "Worlds",
		className: "pointer-events-auto absolute top-28 bottom-36 left-4 hidden w-36 flex-col justify-center gap-0.5 md:flex sm:left-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onFocus("system"),
			className: navClass(focusedId === "system"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-muted" }), "System"]
		}), PRIMARY_BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onFocus(body.id),
			className: navClass(focusedId === body.id),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "size-1.5 rounded-full",
				style: { background: body.swatch }
			}), body.name]
		}, body.id))]
	});
}
function navClass(active) {
	return cn("flex h-8 items-center gap-2 rounded-sm px-2 text-left font-body text-xs tracking-[0.16em] uppercase transition-[color,background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", active ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2/70 hover:text-fg");
}
function MobileChips({ focusedId, onFocus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-1.5 overflow-x-auto pb-0.5 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
			active: focusedId === "system",
			onClick: () => onFocus("system"),
			swatch: "#8b909c",
			children: "System"
		}), PRIMARY_BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
			active: focusedId === body.id,
			onClick: () => onFocus(body.id),
			swatch: body.swatch,
			children: body.name
		}, body.id))]
	});
}
function Chip({ active, onClick, swatch, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-10 shrink-0 items-center gap-2 rounded-full px-3 font-body text-xs tracking-[0.14em] uppercase shadow-border transition-[color,background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", active ? "bg-fg text-bg" : "bg-surface/90 text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "size-1.5 rounded-full",
			style: { background: active ? "currentColor" : swatch }
		}), children]
	});
}
function infoContent(focusedId) {
	if (focusedId === "system") return {
		kicker: "Observatory",
		title: "Sol",
		tagline: "Eight worlds around one star",
		blurb: "Drag to orbit the view. Click a world — or its name — to glide the camera in. Time is elastic: pause, then wind the centuries forward.",
		facts: [
			{
				label: "Worlds",
				value: "8 planets, 1 star"
			},
			{
				label: "Scale",
				value: "Compressed orrery"
			},
			{
				label: "Clock",
				value: "1× = 32s per Earth year"
			}
		]
	};
	const body = BODY_BY_ID[focusedId];
	return {
		kicker: kindLabel(body.kind),
		title: body.name,
		tagline: body.tagline,
		blurb: body.blurb,
		facts: body.facts.slice(0, 4)
	};
}
function InfoCard({ focusedId }) {
	const content = (0, import_react.useMemo)(() => infoContent(focusedId), [focusedId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "panel-enter pointer-events-auto absolute top-28 right-4 hidden w-[22rem] md:block sm:right-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface/92 p-4 shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-body text-[10px] tracking-[0.22em] text-muted uppercase",
					children: content.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-3xl leading-none tracking-tight text-balance text-fg",
					children: content.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-body text-sm text-muted",
					children: content.tagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-body text-sm leading-relaxed text-pretty text-fg/85",
					children: content.blurb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-4 grid grid-cols-2 gap-x-4 gap-y-2.5 border-t border-border pt-3",
					children: content.facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-body text-[10px] tracking-[0.18em] text-subtle uppercase",
						children: fact.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-0.5 font-body text-sm text-fg",
						children: fact.value
					})] }, fact.label))
				})
			]
		})
	}, focusedId);
}
function MobileInfo({ focusedId }) {
	const content = (0, import_react.useMemo)(() => infoContent(focusedId), [focusedId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "panel-enter",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg bg-surface/92 px-3 py-2.5 shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl leading-none tracking-tight text-fg",
					children: content.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-body text-[10px] tracking-[0.18em] text-muted uppercase",
					children: content.kicker
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 font-body text-xs leading-relaxed text-muted",
				children: content.tagline
			})]
		})
	}, focusedId);
}
function Transport({ paused, speed, years, focusedId, onTogglePaused, onSpeed, onOverview }) {
	const bodyName = focusedId === "system" ? "System view" : BODY_BY_ID[focusedId].name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl items-center gap-2 rounded-xl bg-surface/92 p-2 pr-3 pl-2 shadow-border sm:gap-3 sm:p-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "secondary",
				size: "icon",
				"aria-label": paused ? "Resume simulation" : "Pause simulation",
				onClick: onTogglePaused,
				className: "size-11 shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative size-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: cn("absolute inset-0 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-in-out)]", paused ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-none") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: cn("absolute inset-0 ml-px transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-in-out)]", paused ? "scale-100 opacity-100 blur-none" : "scale-[0.25] opacity-0 blur-[4px]") })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-body text-[10px] tracking-[0.18em] text-muted uppercase",
						children: paused ? "Paused" : "Sim speed"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs tabular-nums text-fg",
						children: [
							formatSpeed(speed),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-2 text-subtle",
								children: "·"
							}),
							"Yr ",
							formatYears(years)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: 1,
					step: .001,
					value: [speedToT(speed)],
					onValueChange: ([t]) => onSpeed(tToSpeed(t ?? 0)),
					"aria-label": "Simulation speed"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: onOverview,
				className: "hidden h-11 shrink-0 px-3 text-muted sm:inline-flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tracking-[0.12em] uppercase",
					children: focusedId === "system" ? bodyName : "Overview"
				})]
			})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
var scenePromise = typeof window === "undefined" ? null : import("./scene-pCGjCrI6.mjs");
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientScene, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {})]
	});
}
function ClientScene() {
	const [Scene, setScene] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let alive = true;
		(scenePromise ?? import("./scene-pCGjCrI6.mjs")).then((mod) => {
			if (alive) setScene(() => mod.SolarScene);
		});
		return () => {
			alive = false;
		};
	}, []);
	if (!Scene) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 bg-bg",
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
	});
}
//#endregion
export { PRIMARY_BODIES as a, BODY_BY_ID as i, useSolarStore as n, orbitRadiansPerSecond as o, BODIES as r, spinRadiansPerSecond as s, routes_exports as t };
