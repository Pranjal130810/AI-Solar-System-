import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Vector3, a as Canvas, c as CanvasTexture, d as LinearFilter, f as LinearMipmapLinearFilter, g as SphereGeometry, h as SRGBColorSpace, i as Html, l as Color, m as RepeatWrapping, n as OrbitControls, o as useFrame, p as Object3D, r as Line, s as useThree, t as Stars, u as IcosahedronGeometry } from "../_libs/@react-three/drei+[...].mjs";
import { a as PRIMARY_BODIES, i as BODY_BY_ID, n as useSolarStore, o as orbitRadiansPerSecond, r as BODIES, s as spinRadiansPerSecond } from "./routes-5RiLYydW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scene-pCGjCrI6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var simTime = { current: 0 };
var scratch = new Vector3();
function tickSim(delta, paused, speed) {
	if (!paused) simTime.current += Math.min(delta, .1) * speed;
}
function localOrbit(id, t, out) {
	const body = BODY_BY_ID[id];
	const angle = t * orbitRadiansPerSecond(body) + body.phase;
	const c = Math.cos(angle) * body.distance;
	const s = Math.sin(angle) * body.distance;
	const inc = body.inclination;
	out.set(c, -s * Math.sin(inc), s * Math.cos(inc));
	return out;
}
function getBodyPosition(id, out) {
	if (id === "system" || id === "sun") return out.set(0, 0, 0);
	const body = BODY_BY_ID[id];
	if (body.parent) {
		getBodyPosition(body.parent, out);
		localOrbit(id, simTime.current, scratch);
		return out.add(scratch);
	}
	return localOrbit(id, simTime.current, out);
}
function cameraOffsetFor(id, out) {
	if (id === "system") return out.set(0, 46, 108);
	const body = BODY_BY_ID[id];
	if (id === "sun") return out.set(9.5, 5.4, 16.5);
	const dist = Math.min(Math.max(body.radius * 8.4, 3.4), 26);
	return out.set(dist * .62, dist * .36, dist * .95);
}
function hash(x, y, z) {
	let n = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(z | 0, 1274126177);
	n = Math.imul(n ^ n >>> 13, 1274126177);
	return ((n ^ n >>> 16) >>> 0) / 4294967296;
}
function noise3(x, y, z) {
	const ix = Math.floor(x);
	const iy = Math.floor(y);
	const iz = Math.floor(z);
	const fx = x - ix;
	const fy = y - iy;
	const fz = z - iz;
	const ux = fx * fx * (3 - 2 * fx);
	const uy = fy * fy * (3 - 2 * fy);
	const uz = fz * fz * (3 - 2 * fz);
	const n000 = hash(ix, iy, iz);
	const n100 = hash(ix + 1, iy, iz);
	const n010 = hash(ix, iy + 1, iz);
	const n110 = hash(ix + 1, iy + 1, iz);
	const n001 = hash(ix, iy, iz + 1);
	const n101 = hash(ix + 1, iy, iz + 1);
	const n011 = hash(ix, iy + 1, iz + 1);
	const n111 = hash(ix + 1, iy + 1, iz + 1);
	const nx00 = n000 + (n100 - n000) * ux;
	const nx10 = n010 + (n110 - n010) * ux;
	const nx01 = n001 + (n101 - n001) * ux;
	const nx11 = n011 + (n111 - n011) * ux;
	const nxy0 = nx00 + (nx10 - nx00) * uy;
	return nxy0 + (nx01 + (nx11 - nx01) * uy - nxy0) * uz;
}
function fbm(x, y, z, octaves, lacunarity = 2, gain = .5) {
	let sum = 0;
	let amp = .5;
	let freq = 1;
	let norm = 0;
	const n = Math.min(octaves, 4);
	for (let i = 0; i < n; i++) {
		sum += amp * noise3(x * freq, y * freq, z * freq);
		norm += amp;
		freq *= lacunarity;
		amp *= gain;
	}
	return sum / norm;
}
function spherePoint(u, v) {
	const lon = u * Math.PI * 2;
	const lat = v * Math.PI;
	const sl = Math.sin(lat);
	return {
		x: sl * Math.cos(lon),
		y: Math.cos(lat),
		z: sl * Math.sin(lon),
		lat,
		lon
	};
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function clamp(v, lo = 0, hi = 1) {
	return Math.min(hi, Math.max(lo, v));
}
function mixRgb(a, b, t) {
	return [
		lerp(a[0], b[0], t),
		lerp(a[1], b[1], t),
		lerp(a[2], b[2], t)
	];
}
function paint(width, height, pixel, colorSpace = SRGBColorSpace) {
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("Canvas 2D unavailable");
	const img = ctx.createImageData(width, height);
	const data = img.data;
	for (let y = 0; y < height; y++) {
		const v = (y + .5) / height;
		for (let x = 0; x < width; x++) {
			const u = (x + .5) / width;
			const [r, g, b, a] = pixel(u, v, spherePoint(u, v));
			const i = (y * width + x) * 4;
			data[i] = r;
			data[i + 1] = g;
			data[i + 2] = b;
			data[i + 3] = a;
		}
	}
	ctx.putImageData(img, 0, 0);
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = colorSpace;
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.minFilter = LinearMipmapLinearFilter;
	tex.magFilter = LinearFilter;
	tex.anisotropy = 8;
	tex.needsUpdate = true;
	return tex;
}
function crateredRock(p, seed) {
	const n = fbm(p.x * 3 + seed, p.y * 3, p.z * 3, 6);
	const pits = fbm(p.x * 9 + seed, p.y * 9, p.z * 9, 3);
	const craters = Math.pow(clamp(1 - Math.abs(pits - .42) * 8), 3);
	return clamp(n * .85 - craters * .28);
}
function mercuryPixel(_u, _v, p) {
	const h = crateredRock(p, 2.1);
	const dark = mixRgb(mixRgb([
		78,
		68,
		58
	], [
		186,
		168,
		146
	], h), [
		42,
		38,
		34
	], clamp((.35 - h) * 1.8));
	return [
		dark[0],
		dark[1],
		dark[2],
		255
	];
}
function venusPixel(_u, _v, p) {
	const swirl = fbm(p.x * 2.2 + p.y * .4, p.y * 3.4, p.z * 2.2 - p.y * .6, 5);
	const shade = mixRgb(mixRgb([
		214,
		186,
		132
	], [
		244,
		228,
		196
	], .5 + .5 * Math.sin(p.y * 9 + swirl * 4)), [
		168,
		132,
		92
	], clamp(swirl * .35));
	return [
		shade[0],
		shade[1],
		shade[2],
		255
	];
}
function earthPixel(_u, _v, p) {
	const warped = fbm(p.x * 1.6, p.y * 1.6, p.z * 1.6, 3);
	const n = fbm(p.x * 2.4 + warped * .55, p.y * 2.6, p.z * 2.4 - warped * .4, 6);
	const land = n > .52;
	const ice = Math.abs(p.y) > .86 || Math.abs(p.y) > .72 && n > .48;
	let c;
	if (ice) c = mixRgb([
		226,
		236,
		245
	], [
		248,
		252,
		255
	], n);
	else if (land) {
		c = mixRgb([
			46,
			92,
			54
		], [
			142,
			124,
			72
		], clamp(fbm(p.x * 5, p.y * 5, p.z * 5, 3) * 1.2 - .2));
		if (n > .64) c = mixRgb(c, [
			92,
			78,
			58
		], .55);
	} else c = mixRgb([
		28,
		92,
		148
	], [
		8,
		32,
		72
	], clamp((.52 - n) * 3));
	return [
		c[0],
		c[1],
		c[2],
		255
	];
}
function marsPixel(_u, _v, p) {
	const n = fbm(p.x * 3.1, p.y * 3.1, p.z * 3.1, 6);
	const rift = Math.pow(clamp(1 - Math.abs(p.y + .08 - n * .2) * 7), 2);
	let c = mixRgb([
		96,
		42,
		28
	], [
		196,
		110,
		72
	], n);
	c = mixRgb(c, [
		58,
		36,
		28
	], rift * .65);
	if (Math.abs(p.y) > .82) c = mixRgb(c, [
		236,
		240,
		244
	], clamp((Math.abs(p.y) - .82) * 8));
	return [
		c[0],
		c[1],
		c[2],
		255
	];
}
function jupiterPixel(u, _v, p) {
	const turb = fbm(p.x * 2.2, p.y * 6, p.z * 2.2, 5);
	const bands = .5 + .5 * Math.sin(p.y * 18 + turb * 3.4);
	const palette = [
		[
			214,
			186,
			142
		],
		[
			168,
			122,
			78
		],
		[
			236,
			214,
			176
		],
		[
			124,
			86,
			58
		],
		[
			228,
			196,
			150
		]
	];
	const idx = Math.floor(clamp(bands) * (palette.length - .01));
	const next = Math.min(idx + 1, palette.length - 1);
	let c = mixRgb(palette[idx], palette[next], bands * 4 - idx);
	const dx = Math.abs((u + .18) % 1 - .5);
	const dy = p.y + .22;
	const spot = Math.exp(-(dx * dx * 90 + dy * dy * 220));
	c = mixRgb(c, [
		176,
		72,
		48
	], spot);
	return [
		c[0],
		c[1],
		c[2],
		255
	];
}
function saturnPixel(_u, _v, p) {
	const turb = fbm(p.x * 1.6, p.y * 5.2, p.z * 1.6, 4);
	const shade = mixRgb(mixRgb([
		214,
		196,
		150
	], [
		236,
		224,
		192
	], .5 + .5 * Math.sin(p.y * 14 + turb * 2.2)), [
		168,
		148,
		110
	], clamp(turb * .4));
	return [
		shade[0],
		shade[1],
		shade[2],
		255
	];
}
function uranusPixel(_u, _v, p) {
	const c = mixRgb([
		146,
		204,
		208
	], [
		188,
		232,
		228
	], fbm(p.x * 2, p.y * 2.8, p.z * 2, 4));
	return [
		c[0],
		c[1],
		c[2],
		255
	];
}
function neptunePixel(u, _v, p) {
	const turb = fbm(p.x * 2.4, p.y * 4.2, p.z * 2.4, 5);
	let c = mixRgb([
		42,
		74,
		168
	], [
		96,
		140,
		214
	], .5 + .5 * Math.sin(p.y * 10 + turb * 2));
	const dx = Math.abs((u + .62) % 1 - .5);
	const dy = p.y - .18;
	const spot = Math.exp(-(dx * dx * 70 + dy * dy * 180));
	c = mixRgb(c, [
		18,
		28,
		72
	], spot * .85);
	return [
		c[0],
		c[1],
		c[2],
		255
	];
}
function moonPixel(_u, _v, p) {
	const h = crateredRock(p, 8.4);
	const maria = fbm(p.x * 1.8 + 4, p.y * 1.8, p.z * 1.8, 4);
	let c = mixRgb([
		118,
		114,
		108
	], [
		210,
		204,
		194
	], h);
	if (maria < .42 && p.x > -.2) c = mixRgb(c, [
		72,
		74,
		80
	], .55);
	return [
		c[0],
		c[1],
		c[2],
		255
	];
}
var COLOR_FN = {
	mercury: mercuryPixel,
	venus: venusPixel,
	earth: earthPixel,
	moon: moonPixel,
	mars: marsPixel,
	jupiter: jupiterPixel,
	saturn: saturnPixel,
	uranus: uranusPixel,
	neptune: neptunePixel
};
function bumpFromColor(id) {
	return paint(256, 128, (u, v, p) => {
		const [r, g, b] = COLOR_FN[id](u, v, p);
		const lum = r * .35 + g * .45 + b * .2 | 0;
		return [
			lum,
			lum,
			lum,
			255
		];
	}, "");
}
function earthClouds() {
	return paint(512, 256, (_u, _v, p) => {
		const n = fbm(p.x * 3.4, p.y * 4.2, p.z * 3.4, 4);
		const streaks = fbm(p.x * 6, p.y * 1.4, p.z * 6, 3);
		return [
			244,
			248,
			252,
			clamp((n - .52) * 3.4 + streaks * .15) * 220
		];
	});
}
function venusClouds() {
	return paint(512, 256, (_u, _v, p) => {
		const swirl = fbm(p.x * 1.8 + p.y * .8, p.y * 4, p.z * 1.8, 4);
		const a = 200 + swirl * 40;
		const c = mixRgb([
			236,
			214,
			170
		], [
			250,
			240,
			214
		], swirl);
		return [
			c[0],
			c[1],
			c[2],
			a
		];
	});
}
function makeRingTexture() {
	const size = 512;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas 2D unavailable");
	const img = ctx.createImageData(size, size);
	const data = img.data;
	const inner = 1.28 / 2.18;
	for (let y = 0; y < size; y++) {
		const ny = y / 511 * 2 - 1;
		for (let x = 0; x < size; x++) {
			const nx = x / 511 * 2 - 1;
			const r = Math.sqrt(nx * nx + ny * ny);
			const i = (y * size + x) * 4;
			if (r < inner || r > 1) {
				data[i + 3] = 0;
				continue;
			}
			const t = (r - inner) / .4128440366972478;
			let alpha = 0;
			if (t < .04 || t > .98) alpha = 12;
			else if (t > .44 && t < .54) alpha = 10;
			else {
				const grain = hash(r * 80, nx * 12, ny * 12);
				alpha = (100 + (.45 + .55 * Math.sin(t * 70)) * 120 + grain * 40) * (t > .54 ? .72 : 1);
			}
			const col = mixRgb([
				214,
				196,
				160
			], [
				246,
				236,
				210
			], t);
			data[i] = col[0];
			data[i + 1] = col[1];
			data[i + 2] = col[2];
			data[i + 3] = clamp(alpha, 0, 255);
		}
	}
	ctx.putImageData(img, 0, 0);
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 8;
	tex.needsUpdate = true;
	return tex;
}
function makeHaloTexture() {
	const size = 256;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas 2D unavailable");
	const g = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
	g.addColorStop(0, "rgba(255, 248, 230, 1)");
	g.addColorStop(.12, "rgba(255, 210, 120, 0.55)");
	g.addColorStop(.32, "rgba(255, 150, 50, 0.18)");
	g.addColorStop(.6, "rgba(255, 90, 20, 0.05)");
	g.addColorStop(1, "rgba(0, 0, 0, 0)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, size, size);
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	tex.needsUpdate = true;
	return tex;
}
var cache = /* @__PURE__ */ new Map();
var ringTex = null;
var haloTex = null;
function getPlanetMaps(id) {
	const hit = cache.get(id);
	if (hit) return hit;
	const w = id === "earth" || id === "jupiter" ? 512 : 384;
	const set = {
		map: paint(w, w / 2, COLOR_FN[id]),
		bump: bumpFromColor(id),
		clouds: id === "earth" ? earthClouds() : id === "venus" ? venusClouds() : void 0
	};
	cache.set(id, set);
	return set;
}
function getRingTexture() {
	ringTex ??= makeRingTexture();
	return ringTex;
}
function getHaloTexture() {
	haloTex ??= makeHaloTexture();
	return haloTex;
}
function disposeTextures() {
	for (const set of cache.values()) {
		set.map.dispose();
		set.bump.dispose();
		set.clouds?.dispose();
	}
	cache.clear();
	ringTex?.dispose();
	haloTex?.dispose();
	ringTex = null;
	haloTex = null;
}
var sharedSphere = new SphereGeometry(1, 64, 48);
var cloudSphere = new SphereGeometry(1, 48, 32);
var _pos = new Vector3();
var _offset = new Vector3();
var _desiredCam = new Vector3();
var _move = new Vector3();
var _fromCam = new Vector3();
var _fromTarget = new Vector3();
var _last = new Vector3();
var ATM_VERT = `
varying vec3 vNormal;
varying vec3 vWorldPos;
void main() {
  vNormal = normalize(normalMatrix * normal);
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorldPos = world.xyz;
  gl_Position = projectionMatrix * viewMatrix * world;
}
`;
var ATM_FRAG = `
uniform vec3 uColor;
varying vec3 vNormal;
varying vec3 vWorldPos;
void main() {
  vec3 n = normalize(vNormal);
  vec3 v = normalize(cameraPosition - vWorldPos);
  float fresnel = pow(1.0 - abs(dot(n, v)), 2.6);
  gl_FragColor = vec4(uColor, fresnel * 0.72);
}
`;
var SUN_VERT = `
varying vec3 vPos;
varying vec3 vNormal;
void main() {
  vPos = position;
  vNormal = normalize(normalMatrix * normal);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;
var SUN_FRAG = `
uniform float uTime;
varying vec3 vPos;
varying vec3 vNormal;

float hash(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.11, 0.17, 0.13));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
  vec3 i = floor(x);
  vec3 f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x),
        mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
    mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
        mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}

void main() {
  float n = noise(vPos * 2.8 + vec3(uTime * 0.11, 0.0, uTime * 0.07));
  n += 0.5 * noise(vPos * 6.5 - uTime * 0.16);
  n += 0.25 * noise(vPos * 13.0 + uTime * 0.09);
  vec3 cool = vec3(0.95, 0.42, 0.05);
  vec3 hot = vec3(1.0, 0.96, 0.78);
  vec3 col = mix(cool, hot, clamp(n, 0.0, 1.0));
  col += vec3(1.0, 0.7, 0.25) * pow(max(n, 0.0), 3.0) * 0.55;
  vec3 view = vec3(0.0, 0.0, 1.0);
  float rim = pow(1.0 - abs(dot(normalize(vNormal), view)), 2.0);
  col += vec3(1.0, 0.55, 0.15) * rim * 0.25;
  gl_FragColor = vec4(col, 1.0);
}
`;
function easeOutCubic(t) {
	return 1 - Math.pow(1 - t, 3);
}
function prefersReducedMotion() {
	return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function noopRaycast() {}
function useIsDesktop() {
	const [desktop, setDesktop] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(min-width: 768px)");
		const sync = () => setDesktop(mq.matches);
		sync();
		mq.addEventListener("change", sync);
		return () => mq.removeEventListener("change", sync);
	}, []);
	return desktop;
}
function SimulationClock() {
	const yearsRef = (0, import_react.useRef)(0);
	useFrame((_, delta) => {
		const { paused, speed, setYears } = useSolarStore.getState();
		tickSim(delta, paused, speed);
		const years = simTime.current / 32;
		if (Math.abs(years - yearsRef.current) > .01) {
			yearsRef.current = years;
			setYears(years);
		}
	});
	return null;
}
function CameraDirector({ controlsRef }) {
	const focusedId = useSolarStore((s) => s.focusedId);
	const anim = (0, import_react.useRef)({
		active: true,
		t: 0,
		duration: .95,
		skipFollow: true
	});
	const dragging = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const controls = controlsRef.current;
		if (!controls) return;
		const onStart = () => {
			dragging.current = true;
			anim.current.active = false;
		};
		const onEnd = () => {
			dragging.current = false;
		};
		controls.addEventListener("start", onStart);
		controls.addEventListener("end", onEnd);
		return () => {
			controls.removeEventListener("start", onStart);
			controls.removeEventListener("end", onEnd);
		};
	}, [controlsRef]);
	(0, import_react.useEffect)(() => {
		anim.current.active = true;
		anim.current.t = 0;
		anim.current.duration = prefersReducedMotion() ? .01 : .95;
		const controls = controlsRef.current;
		const camera = controls?.object;
		if (camera && controls) {
			_fromCam.copy(camera.position);
			_fromTarget.copy(controls.target);
		}
	}, [focusedId, controlsRef]);
	useFrame((state, delta) => {
		const controls = controlsRef.current;
		if (!controls) return;
		const d = Math.min(delta, .1);
		getBodyPosition(focusedId, _pos);
		cameraOffsetFor(focusedId, _offset);
		if (anim.current.skipFollow) {
			_last.copy(_pos);
			anim.current.skipFollow = false;
		} else {
			_move.subVectors(_pos, _last);
			state.camera.position.add(_move);
			controls.target.add(_move);
			_fromCam.add(_move);
			_fromTarget.add(_move);
		}
		_last.copy(_pos);
		if (anim.current.active && !dragging.current) {
			anim.current.t += d;
			const e = easeOutCubic(Math.min(1, anim.current.t / anim.current.duration));
			_desiredCam.copy(_pos).add(_offset);
			state.camera.position.lerpVectors(_fromCam, _desiredCam, e);
			controls.target.lerpVectors(_fromTarget, _pos, e);
			if (e >= 1) anim.current.active = false;
		}
		const body = focusedId === "system" ? BODY_BY_ID.sun : BODY_BY_ID[focusedId];
		controls.minDistance = Math.max(body.radius * 2.4, 2.2);
		controls.maxDistance = focusedId === "system" ? 240 : 90;
		controls.update();
	});
	return null;
}
function Atmosphere({ radius, color }) {
	const uniforms = (0, import_react.useMemo)(() => ({ uColor: { value: new Color(color) } }), [color]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		scale: radius * 1.08,
		geometry: sharedSphere,
		raycast: noopRaycast,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("shaderMaterial", {
			uniforms,
			vertexShader: ATM_VERT,
			fragmentShader: ATM_FRAG,
			transparent: true,
			depthWrite: false,
			side: 1,
			blending: 2,
			toneMapped: false
		})
	});
}
function BodyLabel({ body, radius }) {
	const show = useSolarStore((s) => s.showLabels);
	const focusedId = useSolarStore((s) => s.focusedId);
	const setFocused = useSolarStore((s) => s.setFocused);
	const desktop = useIsDesktop();
	if (!show || !desktop) return null;
	const active = focusedId === body.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
		position: [
			0,
			radius * 1.45,
			0
		],
		center: true,
		sprite: true,
		zIndexRange: [8, 0],
		style: { pointerEvents: "none" },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			tabIndex: -1,
			onClick: (e) => {
				e.stopPropagation();
				setFocused(body.id);
			},
			className: "pointer-events-none rounded-full border px-2 py-0.5 font-body text-[10px] font-medium tracking-[0.18em] uppercase transition-[color,background-color,border-color,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] " + (active ? "border-fg/35 bg-fg text-bg" : "border-border bg-bg/80 text-fg/85 hover:border-fg/30 hover:text-fg"),
			children: body.name
		})
	});
}
function PlanetMesh({ body }) {
	const meshRef = (0, import_react.useRef)(null);
	const cloudRef = (0, import_react.useRef)(null);
	const maps = (0, import_react.useMemo)(() => getPlanetMaps(body.id), [body.id]);
	const focusedId = useSolarStore((s) => s.focusedId);
	const setFocused = useSolarStore((s) => s.setFocused);
	const spin = spinRadiansPerSecond(body);
	useFrame((_, delta) => {
		const d = Math.min(delta, .1);
		const { paused, speed } = useSolarStore.getState();
		if (paused) return;
		const step = d * speed;
		if (meshRef.current) meshRef.current.rotation.y += spin * step;
		if (cloudRef.current) cloudRef.current.rotation.y += spin * step * 1.08;
	});
	const isFocus = focusedId === body.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			body.tilt,
			0,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				ref: meshRef,
				geometry: sharedSphere,
				scale: body.radius,
				onClick: (e) => {
					e.stopPropagation();
					setFocused(body.id);
				},
				onPointerOver: (e) => {
					e.stopPropagation();
					document.body.style.cursor = "pointer";
				},
				onPointerOut: () => {
					document.body.style.cursor = "";
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map: maps.map,
					bumpMap: maps.bump,
					bumpScale: body.kind === "terrestrial" || body.kind === "moon" ? .045 : .02,
					roughness: body.kind === "gas-giant" ? .72 : .86,
					metalness: .04,
					emissive: isFocus ? body.swatch : "#000000",
					emissiveIntensity: isFocus ? .12 : 0
				})
			}),
			maps.clouds ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				ref: cloudRef,
				geometry: cloudSphere,
				scale: body.radius * 1.02,
				raycast: noopRaycast,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map: maps.clouds,
					transparent: true,
					depthWrite: false,
					roughness: 1,
					metalness: 0
				})
			}) : null,
			body.atmosphere ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atmosphere, {
				radius: body.radius,
				color: body.atmosphere
			}) : null,
			body.hasRings ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetRings, { radius: body.radius }) : null,
			isFocus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusRing, {
				radius: body.radius,
				color: body.swatch
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyLabel, {
				body,
				radius: body.radius
			})
		]
	});
}
function PlanetRings({ radius }) {
	const tex = (0, import_react.useMemo)(() => getRingTexture(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		rotation: [
			Math.PI / 2,
			0,
			0
		],
		raycast: noopRaycast,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
			radius * 1.28,
			radius * 2.18,
			96
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			map: tex,
			transparent: true,
			side: 2,
			depthWrite: false,
			roughness: .55,
			metalness: .15
		})]
	});
}
function FocusRing({ radius, color }) {
	const ref = (0, import_react.useRef)(null);
	const { camera } = useThree();
	useFrame(() => {
		ref.current?.lookAt(camera.position);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		ref,
		raycast: noopRaycast,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
			radius * 1.55,
			radius * 1.64,
			64
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
			color,
			transparent: true,
			opacity: .55,
			side: 2,
			depthWrite: false,
			toneMapped: false
		})]
	});
}
function OrbitingBody({ body }) {
	const groupRef = (0, import_react.useRef)(null);
	const speed = orbitRadiansPerSecond(body);
	useFrame(() => {
		const g = groupRef.current;
		if (!g) return;
		const angle = simTime.current * speed + body.phase;
		g.position.set(Math.cos(angle) * body.distance, 0, Math.sin(angle) * body.distance);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			body.inclination,
			0,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			ref: groupRef,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetMesh, { body }), body.id === "earth" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {}) : null]
		})
	});
}
function Moon() {
	const moon = BODY_BY_ID.moon;
	const groupRef = (0, import_react.useRef)(null);
	const speed = orbitRadiansPerSecond(moon);
	useFrame(() => {
		const g = groupRef.current;
		if (!g) return;
		const angle = simTime.current * speed + moon.phase;
		g.position.set(Math.cos(angle) * moon.distance, 0, Math.sin(angle) * moon.distance);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			moon.inclination,
			0,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			ref: groupRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetMesh, { body: moon })
		})
	});
}
function OrbitTrail({ body }) {
	const show = useSolarStore((s) => s.showTrails);
	const focusedId = useSolarStore((s) => s.focusedId);
	const points = (0, import_react.useMemo)(() => {
		const pts = [];
		const n = 192;
		for (let i = 0; i <= n; i++) {
			const a = i / n * Math.PI * 2;
			pts.push([
				Math.cos(a) * body.distance,
				0,
				Math.sin(a) * body.distance
			]);
		}
		return pts;
	}, [body.distance]);
	if (!show || body.parent || body.distance <= 0) return null;
	const active = focusedId === body.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			body.inclination,
			0,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
			points,
			color: body.swatch,
			lineWidth: active ? 1.4 : .9,
			transparent: true,
			opacity: active ? .58 : .2,
			depthWrite: false
		})
	});
}
function Sun() {
	const meshRef = (0, import_react.useRef)(null);
	const matRef = (0, import_react.useRef)(null);
	const spriteRef = (0, import_react.useRef)(null);
	const halo = (0, import_react.useMemo)(() => getHaloTexture(), []);
	const setFocused = useSolarStore((s) => s.setFocused);
	const focusedId = useSolarStore((s) => s.focusedId);
	const sun = BODY_BY_ID.sun;
	const uniforms = (0, import_react.useMemo)(() => ({ uTime: { value: 0 } }), []);
	useFrame(() => {
		if (matRef.current) matRef.current.uniforms.uTime.value = simTime.current;
		if (meshRef.current) meshRef.current.rotation.y = simTime.current * spinRadiansPerSecond(sun);
		if (spriteRef.current) {
			const pulse = 1 + Math.sin(simTime.current * .6) * .03;
			spriteRef.current.scale.setScalar(22 * pulse);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			ref: meshRef,
			geometry: sharedSphere,
			scale: sun.radius,
			onClick: (e) => {
				e.stopPropagation();
				setFocused("sun");
			},
			onPointerOver: () => {
				document.body.style.cursor = "pointer";
			},
			onPointerOut: () => {
				document.body.style.cursor = "";
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("shaderMaterial", {
				ref: matRef,
				uniforms,
				vertexShader: SUN_VERT,
				fragmentShader: SUN_FRAG,
				toneMapped: false
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
			ref: spriteRef,
			scale: 22,
			raycast: noopRaycast,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
				map: halo,
				blending: 2,
				depthWrite: false,
				transparent: true,
				opacity: .9,
				toneMapped: false
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atmosphere, {
			radius: sun.radius * .98,
			color: "#ffb060"
		}),
		focusedId === "sun" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusRing, {
			radius: sun.radius,
			color: sun.swatch
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BodyLabel, {
			body: sun,
			radius: sun.radius
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			color: "#fff3d6",
			intensity: 180,
			distance: 0,
			decay: 2
		})
	] });
}
function AsteroidBelt() {
	const meshRef = (0, import_react.useRef)(null);
	const count = 420;
	const geo = (0, import_react.useMemo)(() => new IcosahedronGeometry(1, 0), []);
	const dummy = (0, import_react.useMemo)(() => new Object3D(), []);
	const speeds = (0, import_react.useMemo)(() => {
		const s = new Float32Array(count);
		const radii = new Float32Array(count);
		const y = new Float32Array(count);
		const phase = new Float32Array(count);
		const scale = new Float32Array(count);
		for (let i = 0; i < count; i++) {
			radii[i] = 28.4 + (Math.random() * 2 - .35) * 2.6;
			y[i] = (Math.random() - .5) * .7;
			phase[i] = Math.random() * Math.PI * 2;
			s[i] = .035 + Math.random() * .02;
			scale[i] = .018 + Math.random() * .046;
		}
		return {
			radii,
			y,
			phase,
			speeds: s,
			scale
		};
	}, []);
	useFrame(() => {
		const mesh = meshRef.current;
		if (!mesh) return;
		const t = simTime.current;
		for (let i = 0; i < count; i++) {
			const a = (speeds.phase[i] ?? 0) + t * (speeds.speeds[i] ?? 0);
			const r = speeds.radii[i] ?? 29;
			dummy.position.set(Math.cos(a) * r, speeds.y[i] ?? 0, Math.sin(a) * r);
			dummy.rotation.set(a * .4, a, a * .2);
			dummy.scale.setScalar(speeds.scale[i] ?? .03);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		mesh.instanceMatrix.needsUpdate = true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("instancedMesh", {
		ref: meshRef,
		args: [
			geo,
			void 0,
			count
		],
		frustumCulled: false,
		raycast: noopRaycast,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#6d675f",
			roughness: .96,
			metalness: .08
		})
	});
}
function World() {
	const controlsRef = (0, import_react.useRef)(null);
	const isMobile = typeof window !== "undefined" && window.innerWidth < 640;
	(0, import_react.useEffect)(() => {
		return () => {
			disposeTextures();
			document.body.style.cursor = "";
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#03040a"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", {
			intensity: .045,
			color: "#9aa4c0"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#141826",
			"#020208",
			.22
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stars, {
			radius: 180,
			depth: 70,
			count: isMobile ? 2800 : 5200,
			factor: 3.4,
			saturation: 0,
			fade: true,
			speed: .35
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimulationClock, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
			ref: controlsRef,
			makeDefault: true,
			enablePan: false,
			enableDamping: true,
			dampingFactor: .08,
			minPolarAngle: .12,
			maxPolarAngle: Math.PI - .12,
			minDistance: 4,
			maxDistance: 240,
			rotateSpeed: .72,
			zoomSpeed: .85
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraDirector, { controlsRef }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}),
		PRIMARY_BODIES.filter((b) => b.id !== "sun").map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitingBody, { body }, body.id)),
		BODIES.filter((b) => b.distance > 0 && !b.parent).map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitTrail, { body }, `trail-${body.id}`)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AsteroidBelt, {})
	] });
}
function SolarScene() {
	const isMobile = typeof window !== "undefined" && window.innerWidth < 640;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
		className: "h-full w-full touch-none",
		camera: {
			position: [
				0,
				46,
				isMobile ? 132 : 108
			],
			fov: isMobile ? 48 : 42,
			near: .08,
			far: 500
		},
		dpr: [1, 1.75],
		gl: {
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		},
		onCreated: ({ gl }) => {
			gl.setClearColor("#03040a");
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(World, {})
	});
}
//#endregion
export { SolarScene };
