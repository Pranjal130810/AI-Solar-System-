//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BDShTsXr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-RZvmQ5_0.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-RZvmQ5_0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CvpPZ9x3.js"]
	}
} });
//#endregion
export { tsrStartManifest };
