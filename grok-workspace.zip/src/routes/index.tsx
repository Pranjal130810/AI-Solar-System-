import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";
import { Hud } from "@/components/solar/hud";

const scenePromise =
  typeof window === "undefined"
    ? null
    : import("@/components/solar/scene");

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <ClientScene />
      <Hud />
    </main>
  );
}

function ClientScene() {
  const [Scene, setScene] = useState<ComponentType | null>(null);

  useEffect(() => {
    let alive = true;
    const p = scenePromise ?? import("@/components/solar/scene");
    void p.then((mod) => {
      if (alive) setScene(() => mod.SolarScene);
    });
    return () => {
      alive = false;
    };
  }, []);

  if (!Scene) {
    return <div className="absolute inset-0 bg-bg" aria-hidden="true" />;
  }

  return (
    <div className="absolute inset-0">
      <Scene />
    </div>
  );
}
