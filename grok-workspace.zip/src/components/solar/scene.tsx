import { Html, Line, OrbitControls, Stars } from "@react-three/drei";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState, type RefObject } from "react";
import {
  AdditiveBlending,
  BackSide,
  Color,
  DoubleSide,
  Group,
  IcosahedronGeometry,
  InstancedMesh,
  Mesh,
  Object3D,
  ShaderMaterial,
  SphereGeometry,
  Sprite,
  Vector3,
} from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import {
  BODIES,
  BODY_BY_ID,
  type Body,
  type BodyId,
  EARTH_YEAR_SECONDS,
  orbitRadiansPerSecond,
  PRIMARY_BODIES,
  spinRadiansPerSecond,
} from "@/lib/solar/bodies";
import {
  cameraOffsetFor,
  getBodyPosition,
  simTime,
  tickSim,
} from "@/lib/solar/simulation";
import { useSolarStore } from "@/lib/solar/store";
import {
  disposeTextures,
  getHaloTexture,
  getPlanetMaps,
  getRingTexture,
} from "@/lib/solar/textures";

const sharedSphere = new SphereGeometry(1, 64, 48);
const cloudSphere = new SphereGeometry(1, 48, 32);
const _pos = new Vector3();
const _offset = new Vector3();
const _desiredCam = new Vector3();
const _move = new Vector3();
const _fromCam = new Vector3();
const _fromTarget = new Vector3();
const _last = new Vector3();

const ATM_VERT = /* glsl */ `
varying vec3 vNormal;
varying vec3 vWorldPos;
void main() {
  vNormal = normalize(normalMatrix * normal);
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorldPos = world.xyz;
  gl_Position = projectionMatrix * viewMatrix * world;
}
`;

const ATM_FRAG = /* glsl */ `
uniform vec3 uColor;
varying vec3 vNormal;
varying vec3 vWorldPos;
void main() {
  vec3 n = normalize(vNormal);
  vec3 v = normalize(cameraPosition - vWorldPos);
  float fresnel = pow(1.0 - abs(dot(n, v)), 2.6);
  gl_FragColor = vec4(uColor, fresnel * 0.72);
}
`;

const SUN_VERT = /* glsl */ `
varying vec3 vPos;
varying vec3 vNormal;
void main() {
  vPos = position;
  vNormal = normalize(normalMatrix * normal);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const SUN_FRAG = /* glsl */ `
uniform float uTime;
varying vec3 vPos;
varying vec3 vNormal;

float hash(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.11, 0.17, 0.13));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
  vec3 i = floor(x);
  vec3 f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x),
        mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
    mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
        mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}

void main() {
  float n = noise(vPos * 2.8 + vec3(uTime * 0.11, 0.0, uTime * 0.07));
  n += 0.5 * noise(vPos * 6.5 - uTime * 0.16);
  n += 0.25 * noise(vPos * 13.0 + uTime * 0.09);
  vec3 cool = vec3(0.95, 0.42, 0.05);
  vec3 hot = vec3(1.0, 0.96, 0.78);
  vec3 col = mix(cool, hot, clamp(n, 0.0, 1.0));
  col += vec3(1.0, 0.7, 0.25) * pow(max(n, 0.0), 3.0) * 0.55;
  vec3 view = vec3(0.0, 0.0, 1.0);
  float rim = pow(1.0 - abs(dot(normalize(vNormal), view)), 2.0);
  col += vec3(1.0, 0.55, 0.15) * rim * 0.25;
  gl_FragColor = vec4(col, 1.0);
}
`;

function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

function prefersReducedMotion() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

function noopRaycast() {}

function useIsDesktop() {
  const [desktop, setDesktop] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const sync = () => setDesktop(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);
  return desktop;
}

function SimulationClock() {
  const yearsRef = useRef(0);
  useFrame((_, delta) => {
    const { paused, speed, setYears } = useSolarStore.getState();
    tickSim(delta, paused, speed);
    const years = simTime.current / EARTH_YEAR_SECONDS;
    if (Math.abs(years - yearsRef.current) > 0.01) {
      yearsRef.current = years;
      setYears(years);
    }
  });
  return null;
}

function CameraDirector({
  controlsRef,
}: {
  controlsRef: RefObject<OrbitControlsImpl | null>;
}) {
  const focusedId = useSolarStore((s) => s.focusedId);
  const anim = useRef({
    active: true,
    t: 0,
    duration: 0.95,
    skipFollow: true,
  });
  const dragging = useRef(false);

  useEffect(() => {
    const controls = controlsRef.current;
    if (!controls) return;
    const onStart = () => {
      dragging.current = true;
      anim.current.active = false;
    };
    const onEnd = () => {
      dragging.current = false;
    };
    controls.addEventListener("start", onStart);
    controls.addEventListener("end", onEnd);
    return () => {
      controls.removeEventListener("start", onStart);
      controls.removeEventListener("end", onEnd);
    };
  }, [controlsRef]);

  useEffect(() => {
    anim.current.active = true;
    anim.current.t = 0;
    anim.current.duration = prefersReducedMotion() ? 0.01 : 0.95;
    const controls = controlsRef.current;
    const camera = controls?.object;
    if (camera && controls) {
      _fromCam.copy(camera.position);
      _fromTarget.copy(controls.target);
    }
  }, [focusedId, controlsRef]);

  useFrame((state, delta) => {
    const controls = controlsRef.current;
    if (!controls) return;
    const d = Math.min(delta, 0.1);
    getBodyPosition(focusedId, _pos);
    cameraOffsetFor(focusedId, _offset);

    if (anim.current.skipFollow) {
      _last.copy(_pos);
      anim.current.skipFollow = false;
    } else {
      _move.subVectors(_pos, _last);
      state.camera.position.add(_move);
      controls.target.add(_move);
      _fromCam.add(_move);
      _fromTarget.add(_move);
    }
    _last.copy(_pos);

    if (anim.current.active && !dragging.current) {
      anim.current.t += d;
      const e = easeOutCubic(
        Math.min(1, anim.current.t / anim.current.duration),
      );
      _desiredCam.copy(_pos).add(_offset);
      state.camera.position.lerpVectors(_fromCam, _desiredCam, e);
      controls.target.lerpVectors(_fromTarget, _pos, e);
      if (e >= 1) anim.current.active = false;
    }

    const body =
      focusedId === "system" ? BODY_BY_ID.sun : BODY_BY_ID[focusedId];
    controls.minDistance = Math.max(body.radius * 2.4, 2.2);
    controls.maxDistance = focusedId === "system" ? 240 : 90;
    controls.update();
  });

  return null;
}

function Atmosphere({ radius, color }: { radius: number; color: string }) {
  const uniforms = useMemo(
    () => ({ uColor: { value: new Color(color) } }),
    [color],
  );
  return (
    <mesh scale={radius * 1.08} geometry={sharedSphere} raycast={noopRaycast}>
      <shaderMaterial
        uniforms={uniforms}
        vertexShader={ATM_VERT}
        fragmentShader={ATM_FRAG}
        transparent
        depthWrite={false}
        side={BackSide}
        blending={AdditiveBlending}
        toneMapped={false}
      />
    </mesh>
  );
}

function BodyLabel({ body, radius }: { body: Body; radius: number }) {
  const show = useSolarStore((s) => s.showLabels);
  const focusedId = useSolarStore((s) => s.focusedId);
  const setFocused = useSolarStore((s) => s.setFocused);
  const desktop = useIsDesktop();
  if (!show || !desktop) return null;
  const active = focusedId === body.id;
  return (
    <Html
      position={[0, radius * 1.45, 0]}
      center
      sprite
      zIndexRange={[8, 0]}
      style={{ pointerEvents: "none" }}
    >
      <button
        type="button"
        tabIndex={-1}
        onClick={(e) => {
          e.stopPropagation();
          setFocused(body.id);
        }}
        className={
          "pointer-events-none rounded-full border px-2 py-0.5 font-body text-[10px] font-medium tracking-[0.18em] uppercase transition-[color,background-color,border-color,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] " +
          (active
            ? "border-fg/35 bg-fg text-bg"
            : "border-border bg-bg/80 text-fg/85 hover:border-fg/30 hover:text-fg")
        }
      >
        {body.name}
      </button>
    </Html>
  );
}

function PlanetMesh({ body }: { body: Body }) {
  const meshRef = useRef<Mesh>(null);
  const cloudRef = useRef<Mesh>(null);
  const maps = useMemo(
    () => getPlanetMaps(body.id as Exclude<BodyId, "sun">),
    [body.id],
  );
  const focusedId = useSolarStore((s) => s.focusedId);
  const setFocused = useSolarStore((s) => s.setFocused);
  const spin = spinRadiansPerSecond(body);

  useFrame((_, delta) => {
    const d = Math.min(delta, 0.1);
    const { paused, speed } = useSolarStore.getState();
    if (paused) return;
    const step = d * speed;
    if (meshRef.current) meshRef.current.rotation.y += spin * step;
    if (cloudRef.current) {
      cloudRef.current.rotation.y += spin * step * 1.08;
    }
  });

  const isFocus = focusedId === body.id;

  return (
    <group rotation={[body.tilt, 0, 0]}>
      <mesh
        ref={meshRef}
        geometry={sharedSphere}
        scale={body.radius}
        onClick={(e) => {
          e.stopPropagation();
          setFocused(body.id);
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          document.body.style.cursor = "";
        }}
      >
        <meshStandardMaterial
          map={maps.map}
          bumpMap={maps.bump}
          bumpScale={
            body.kind === "terrestrial" || body.kind === "moon" ? 0.045 : 0.02
          }
          roughness={body.kind === "gas-giant" ? 0.72 : 0.86}
          metalness={0.04}
          emissive={isFocus ? body.swatch : "#000000"}
          emissiveIntensity={isFocus ? 0.12 : 0}
        />
      </mesh>
      {maps.clouds ? (
        <mesh
          ref={cloudRef}
          geometry={cloudSphere}
          scale={body.radius * 1.02}
          raycast={noopRaycast}
        >
          <meshStandardMaterial
            map={maps.clouds}
            transparent
            depthWrite={false}
            roughness={1}
            metalness={0}
          />
        </mesh>
      ) : null}
      {body.atmosphere ? (
        <Atmosphere radius={body.radius} color={body.atmosphere} />
      ) : null}
      {body.hasRings ? <PlanetRings radius={body.radius} /> : null}
      {isFocus ? <FocusRing radius={body.radius} color={body.swatch} /> : null}
      <BodyLabel body={body} radius={body.radius} />
    </group>
  );
}

function PlanetRings({ radius }: { radius: number }) {
  const tex = useMemo(() => getRingTexture(), []);
  return (
    <mesh rotation={[Math.PI / 2, 0, 0]} raycast={noopRaycast}>
      <ringGeometry args={[radius * 1.28, radius * 2.18, 96]} />
      <meshStandardMaterial
        map={tex}
        transparent
        side={DoubleSide}
        depthWrite={false}
        roughness={0.55}
        metalness={0.15}
      />
    </mesh>
  );
}

function FocusRing({ radius, color }: { radius: number; color: string }) {
  const ref = useRef<Mesh>(null);
  const { camera } = useThree();
  useFrame(() => {
    ref.current?.lookAt(camera.position);
  });
  return (
    <mesh ref={ref} raycast={noopRaycast}>
      <ringGeometry args={[radius * 1.55, radius * 1.64, 64]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.55}
        side={DoubleSide}
        depthWrite={false}
        toneMapped={false}
      />
    </mesh>
  );
}

function OrbitingBody({ body }: { body: Body }) {
  const groupRef = useRef<Group>(null);
  const speed = orbitRadiansPerSecond(body);

  useFrame(() => {
    const g = groupRef.current;
    if (!g) return;
    const angle = simTime.current * speed + body.phase;
    g.position.set(
      Math.cos(angle) * body.distance,
      0,
      Math.sin(angle) * body.distance,
    );
  });

  return (
    <group rotation={[body.inclination, 0, 0]}>
      <group ref={groupRef}>
        <PlanetMesh body={body} />
        {body.id === "earth" ? <Moon /> : null}
      </group>
    </group>
  );
}

function Moon() {
  const moon = BODY_BY_ID.moon;
  const groupRef = useRef<Group>(null);
  const speed = orbitRadiansPerSecond(moon);

  useFrame(() => {
    const g = groupRef.current;
    if (!g) return;
    const angle = simTime.current * speed + moon.phase;
    g.position.set(
      Math.cos(angle) * moon.distance,
      0,
      Math.sin(angle) * moon.distance,
    );
  });

  return (
    <group rotation={[moon.inclination, 0, 0]}>
      <group ref={groupRef}>
        <PlanetMesh body={moon} />
      </group>
    </group>
  );
}

function OrbitTrail({ body }: { body: Body }) {
  const show = useSolarStore((s) => s.showTrails);
  const focusedId = useSolarStore((s) => s.focusedId);
  const points = useMemo(() => {
    const pts: [number, number, number][] = [];
    const n = 192;
    for (let i = 0; i <= n; i++) {
      const a = (i / n) * Math.PI * 2;
      pts.push([
        Math.cos(a) * body.distance,
        0,
        Math.sin(a) * body.distance,
      ]);
    }
    return pts;
  }, [body.distance]);
  if (!show || body.parent || body.distance <= 0) return null;
  const active = focusedId === body.id;
  return (
    <group rotation={[body.inclination, 0, 0]}>
      <Line
        points={points}
        color={body.swatch}
        lineWidth={active ? 1.4 : 0.9}
        transparent
        opacity={active ? 0.58 : 0.2}
        depthWrite={false}
      />
    </group>
  );
}

function Sun() {
  const meshRef = useRef<Mesh>(null);
  const matRef = useRef<ShaderMaterial>(null);
  const spriteRef = useRef<Sprite>(null);
  const halo = useMemo(() => getHaloTexture(), []);
  const setFocused = useSolarStore((s) => s.setFocused);
  const focusedId = useSolarStore((s) => s.focusedId);
  const sun = BODY_BY_ID.sun;
  const uniforms = useMemo(() => ({ uTime: { value: 0 } }), []);

  useFrame(() => {
    if (matRef.current) matRef.current.uniforms.uTime.value = simTime.current;
    if (meshRef.current) {
      meshRef.current.rotation.y = simTime.current * spinRadiansPerSecond(sun);
    }
    if (spriteRef.current) {
      const pulse = 1 + Math.sin(simTime.current * 0.6) * 0.03;
      spriteRef.current.scale.setScalar(22 * pulse);
    }
  });

  return (
    <group>
      <mesh
        ref={meshRef}
        geometry={sharedSphere}
        scale={sun.radius}
        onClick={(e) => {
          e.stopPropagation();
          setFocused("sun");
        }}
        onPointerOver={() => {
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          document.body.style.cursor = "";
        }}
      >
        <shaderMaterial
          ref={matRef}
          uniforms={uniforms}
          vertexShader={SUN_VERT}
          fragmentShader={SUN_FRAG}
          toneMapped={false}
        />
      </mesh>
      <sprite ref={spriteRef} scale={22} raycast={noopRaycast}>
        <spriteMaterial
          map={halo}
          blending={AdditiveBlending}
          depthWrite={false}
          transparent
          opacity={0.9}
          toneMapped={false}
        />
      </sprite>
      <Atmosphere radius={sun.radius * 0.98} color="#ffb060" />
      {focusedId === "sun" ? (
        <FocusRing radius={sun.radius} color={sun.swatch} />
      ) : null}
      <BodyLabel body={sun} radius={sun.radius} />
      <pointLight color="#fff3d6" intensity={180} distance={0} decay={2} />
    </group>
  );
}

function AsteroidBelt() {
  const meshRef = useRef<InstancedMesh>(null);
  const count = 420;
  const geo = useMemo(() => new IcosahedronGeometry(1, 0), []);
  const dummy = useMemo(() => new Object3D(), []);
  const speeds = useMemo(() => {
    const s = new Float32Array(count);
    const radii = new Float32Array(count);
    const y = new Float32Array(count);
    const phase = new Float32Array(count);
    const scale = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const u = Math.random();
      radii[i] = 28.4 + (u * 2 - 0.35) * 2.6;
      y[i] = (Math.random() - 0.5) * 0.7;
      phase[i] = Math.random() * Math.PI * 2;
      s[i] = 0.035 + Math.random() * 0.02;
      scale[i] = 0.018 + Math.random() * 0.046;
    }
    return { radii, y, phase, speeds: s, scale };
  }, []);

  useFrame(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const t = simTime.current;
    for (let i = 0; i < count; i++) {
      const a = (speeds.phase[i] ?? 0) + t * (speeds.speeds[i] ?? 0);
      const r = speeds.radii[i] ?? 29;
      dummy.position.set(Math.cos(a) * r, speeds.y[i] ?? 0, Math.sin(a) * r);
      dummy.rotation.set(a * 0.4, a, a * 0.2);
      dummy.scale.setScalar(speeds.scale[i] ?? 0.03);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[geo, undefined, count]}
      frustumCulled={false}
      raycast={noopRaycast}
    >
      <meshStandardMaterial color="#6d675f" roughness={0.96} metalness={0.08} />
    </instancedMesh>
  );
}

function World() {
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const isMobile =
    typeof window !== "undefined" && window.innerWidth < 640;

  useEffect(() => {
    return () => {
      disposeTextures();
      document.body.style.cursor = "";
    };
  }, []);

  return (
    <>
      <color attach="background" args={["#03040a"]} />
      <ambientLight intensity={0.045} color="#9aa4c0" />
      <hemisphereLight args={["#141826", "#020208", 0.22]} />
      <Stars
        radius={180}
        depth={70}
        count={isMobile ? 2800 : 5200}
        factor={3.4}
        saturation={0}
        fade
        speed={0.35}
      />
      <SimulationClock />
      <OrbitControls
        ref={controlsRef}
        makeDefault
        enablePan={false}
        enableDamping
        dampingFactor={0.08}
        minPolarAngle={0.12}
        maxPolarAngle={Math.PI - 0.12}
        minDistance={4}
        maxDistance={240}
        rotateSpeed={0.72}
        zoomSpeed={0.85}
      />
      <CameraDirector controlsRef={controlsRef} />
      <Sun />
      {PRIMARY_BODIES.filter((b) => b.id !== "sun").map((body) => (
        <OrbitingBody key={body.id} body={body} />
      ))}
      {BODIES.filter((b) => b.distance > 0 && !b.parent).map((body) => (
        <OrbitTrail key={`trail-${body.id}`} body={body} />
      ))}
      <AsteroidBelt />
    </>
  );
}

export function SolarScene() {
  const isMobile = typeof window !== "undefined" && window.innerWidth < 640;
  const fov = isMobile ? 48 : 42;
  const z = isMobile ? 132 : 108;

  return (
    <Canvas
      className="h-full w-full touch-none"
      camera={{ position: [0, 46, z], fov, near: 0.08, far: 500 }}
      dpr={[1, 1.75]}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      }}
      onCreated={({ gl }) => {
        gl.setClearColor("#03040a");
      }}
    >
      <World />
    </Canvas>
  );
}
