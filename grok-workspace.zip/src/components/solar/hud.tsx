import { Eye, EyeOff, Orbit, Pause, Play, RotateCcw } from "lucide-react";
import { useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  BODY_BY_ID,
  type FocusId,
  kindLabel,
  PRIMARY_BODIES,
} from "@/lib/solar/bodies";
import { SPEED_MAX, SPEED_MIN, useSolarStore } from "@/lib/solar/store";
import { cn } from "@/lib/utils";

function speedToT(speed: number) {
  return Math.log(speed / SPEED_MIN) / Math.log(SPEED_MAX / SPEED_MIN);
}

function tToSpeed(t: number) {
  return SPEED_MIN * Math.pow(SPEED_MAX / SPEED_MIN, t);
}

function formatSpeed(speed: number) {
  if (speed >= 10) return `${Math.round(speed)}×`;
  if (speed >= 1) return `${speed.toFixed(1)}×`;
  return `${speed.toFixed(2)}×`;
}

function formatYears(years: number) {
  if (years < 10) return years.toFixed(2);
  if (years < 100) return years.toFixed(1);
  return years.toFixed(0);
}

export function Hud() {
  const paused = useSolarStore((s) => s.paused);
  const speed = useSolarStore((s) => s.speed);
  const focusedId = useSolarStore((s) => s.focusedId);
  const showLabels = useSolarStore((s) => s.showLabels);
  const showTrails = useSolarStore((s) => s.showTrails);
  const years = useSolarStore((s) => s.years);
  const togglePaused = useSolarStore((s) => s.togglePaused);
  const setSpeed = useSolarStore((s) => s.setSpeed);
  const setFocused = useSolarStore((s) => s.setFocused);
  const toggleLabels = useSolarStore((s) => s.toggleLabels);
  const toggleTrails = useSolarStore((s) => s.toggleTrails);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        togglePaused();
      } else if (e.code === "Escape") {
        setFocused("system");
      } else if (e.key === "l" || e.key === "L") {
        toggleLabels();
      } else if (e.key === "t" || e.key === "T") {
        toggleTrails();
      } else if (e.key === "=" || e.key === "+") {
        setSpeed(speed * 1.25);
      } else if (e.key === "-" || e.key === "_") {
        setSpeed(speed / 1.25);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [speed, setFocused, setSpeed, toggleLabels, togglePaused, toggleTrails]);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 text-fg">
      <Wordmark />
      <div className="pointer-events-auto absolute top-4 right-4 flex items-center gap-1.5 sm:top-6 sm:right-6">
        <span className="hidden md:inline-flex">
          <IconToggle
            pressed={showLabels}
            onPressed={toggleLabels}
            label={showLabels ? "Hide labels" : "Show labels"}
          >
            {showLabels ? <Eye /> : <EyeOff />}
          </IconToggle>
        </span>
        <IconToggle
          pressed={showTrails}
          onPressed={toggleTrails}
          label={showTrails ? "Hide orbits" : "Show orbits"}
        >
          <Orbit />
        </IconToggle>
      </div>

      <DesktopNavigator focusedId={focusedId} onFocus={setFocused} />
      <InfoCard focusedId={focusedId} />

      <div className="pointer-events-auto absolute inset-x-3 bottom-3 flex flex-col gap-2 md:hidden">
        <MobileInfo focusedId={focusedId} />
        <MobileChips focusedId={focusedId} onFocus={setFocused} />
        <Transport
          paused={paused}
          speed={speed}
          years={years}
          focusedId={focusedId}
          onTogglePaused={togglePaused}
          onSpeed={setSpeed}
          onOverview={() => setFocused("system")}
        />
      </div>

      <div className="pointer-events-auto absolute inset-x-6 bottom-5 hidden md:block">
        <Transport
          paused={paused}
          speed={speed}
          years={years}
          focusedId={focusedId}
          onTogglePaused={togglePaused}
          onSpeed={setSpeed}
          onOverview={() => setFocused("system")}
        />
      </div>
    </div>
  );
}

function Wordmark() {
  return (
    <div className="absolute top-4 left-4 pr-24 sm:top-6 sm:left-6">
      <p className="font-display text-2xl leading-none tracking-tight text-fg sm:text-3xl">
        Orrery
      </p>
      <p className="mt-1.5 max-w-[16rem] font-body text-[11px] leading-snug tracking-[0.22em] text-muted uppercase">
        A kinetic model of the solar system
      </p>
    </div>
  );
}

function IconToggle({
  pressed,
  onPressed,
  label,
  children,
}: {
  pressed: boolean;
  onPressed: () => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <Button
      type="button"
      variant="secondary"
      size="icon-sm"
      aria-pressed={pressed}
      aria-label={label}
      title={label}
      onClick={onPressed}
      className={cn(
        "size-11 shadow-border",
        pressed ? "text-fg" : "text-muted",
      )}
    >
      {children}
    </Button>
  );
}

function DesktopNavigator({
  focusedId,
  onFocus,
}: {
  focusedId: FocusId;
  onFocus: (id: FocusId) => void;
}) {
  return (
    <nav
      aria-label="Worlds"
      className="pointer-events-auto absolute top-28 bottom-36 left-4 hidden w-36 flex-col justify-center gap-0.5 md:flex sm:left-6"
    >
      <button
        type="button"
        onClick={() => onFocus("system")}
        className={navClass(focusedId === "system")}
      >
        <span className="size-1.5 rounded-full bg-muted" />
        System
      </button>
      {PRIMARY_BODIES.map((body) => (
        <button
          key={body.id}
          type="button"
          onClick={() => onFocus(body.id)}
          className={navClass(focusedId === body.id)}
        >
          <span
            className="size-1.5 rounded-full"
            style={{ background: body.swatch }}
          />
          {body.name}
        </button>
      ))}
    </nav>
  );
}

function navClass(active: boolean) {
  return cn(
    "flex h-8 items-center gap-2 rounded-sm px-2 text-left font-body text-xs tracking-[0.16em] uppercase transition-[color,background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
    active
      ? "bg-surface-2 text-fg"
      : "text-muted hover:bg-surface-2/70 hover:text-fg",
  );
}

function MobileChips({
  focusedId,
  onFocus,
}: {
  focusedId: FocusId;
  onFocus: (id: FocusId) => void;
}) {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-0.5 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      <Chip
        active={focusedId === "system"}
        onClick={() => onFocus("system")}
        swatch="#8b909c"
      >
        System
      </Chip>
      {PRIMARY_BODIES.map((body) => (
        <Chip
          key={body.id}
          active={focusedId === body.id}
          onClick={() => onFocus(body.id)}
          swatch={body.swatch}
        >
          {body.name}
        </Chip>
      ))}
    </div>
  );
}

function Chip({
  active,
  onClick,
  swatch,
  children,
}: {
  active: boolean;
  onClick: () => void;
  swatch: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex h-10 shrink-0 items-center gap-2 rounded-full px-3 font-body text-xs tracking-[0.14em] uppercase shadow-border transition-[color,background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
        active ? "bg-fg text-bg" : "bg-surface/90 text-fg",
      )}
    >
      <span
        className="size-1.5 rounded-full"
        style={{ background: active ? "currentColor" : swatch }}
      />
      {children}
    </button>
  );
}

function infoContent(focusedId: FocusId) {
  if (focusedId === "system") {
    return {
      kicker: "Observatory",
      title: "Sol",
      tagline: "Eight worlds around one star",
      blurb:
        "Drag to orbit the view. Click a world — or its name — to glide the camera in. Time is elastic: pause, then wind the centuries forward.",
      facts: [
        { label: "Worlds", value: "8 planets, 1 star" },
        { label: "Scale", value: "Compressed orrery" },
        { label: "Clock", value: "1× = 32s per Earth year" },
      ],
    };
  }
  const body = BODY_BY_ID[focusedId];
  return {
    kicker: kindLabel(body.kind),
    title: body.name,
    tagline: body.tagline,
    blurb: body.blurb,
    facts: body.facts.slice(0, 4),
  };
}

function InfoCard({ focusedId }: { focusedId: FocusId }) {
  const content = useMemo(() => infoContent(focusedId), [focusedId]);

  return (
    <aside
      key={focusedId}
      className="panel-enter pointer-events-auto absolute top-28 right-4 hidden w-[22rem] md:block sm:right-6"
    >
      <div className="rounded-xl bg-surface/92 p-4 shadow-border">
        <p className="font-body text-[10px] tracking-[0.22em] text-muted uppercase">
          {content.kicker}
        </p>
        <h2 className="mt-1 font-display text-3xl leading-none tracking-tight text-balance text-fg">
          {content.title}
        </h2>
        <p className="mt-2 font-body text-sm text-muted">{content.tagline}</p>
        <p className="mt-3 font-body text-sm leading-relaxed text-pretty text-fg/85">
          {content.blurb}
        </p>
        <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2.5 border-t border-border pt-3">
          {content.facts.map((fact) => (
            <div key={fact.label}>
              <dt className="font-body text-[10px] tracking-[0.18em] text-subtle uppercase">
                {fact.label}
              </dt>
              <dd className="mt-0.5 font-body text-sm text-fg">{fact.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </aside>
  );
}

function MobileInfo({ focusedId }: { focusedId: FocusId }) {
  const content = useMemo(() => infoContent(focusedId), [focusedId]);
  return (
    <div key={focusedId} className="panel-enter">
      <div className="rounded-lg bg-surface/92 px-3 py-2.5 shadow-border">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-display text-xl leading-none tracking-tight text-fg">
            {content.title}
          </h2>
          <p className="font-body text-[10px] tracking-[0.18em] text-muted uppercase">
            {content.kicker}
          </p>
        </div>
        <p className="mt-1.5 font-body text-xs leading-relaxed text-muted">
          {content.tagline}
        </p>
      </div>
    </div>
  );
}

function Transport({
  paused,
  speed,
  years,
  focusedId,
  onTogglePaused,
  onSpeed,
  onOverview,
}: {
  paused: boolean;
  speed: number;
  years: number;
  focusedId: FocusId;
  onTogglePaused: () => void;
  onSpeed: (n: number) => void;
  onOverview: () => void;
}) {
  const bodyName =
    focusedId === "system" ? "System view" : BODY_BY_ID[focusedId].name;

  return (
    <div className="mx-auto flex max-w-3xl items-center gap-2 rounded-xl bg-surface/92 p-2 pr-3 pl-2 shadow-border sm:gap-3 sm:p-2.5">
      <Button
        type="button"
        variant="secondary"
        size="icon"
        aria-label={paused ? "Resume simulation" : "Pause simulation"}
        onClick={onTogglePaused}
        className="size-11 shrink-0"
      >
        <span className="relative size-4">
          <Pause
            className={cn(
              "absolute inset-0 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-in-out)]",
              paused
                ? "scale-[0.25] opacity-0 blur-[4px]"
                : "scale-100 opacity-100 blur-none",
            )}
          />
          <Play
            className={cn(
              "absolute inset-0 ml-px transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-in-out)]",
              paused
                ? "scale-100 opacity-100 blur-none"
                : "scale-[0.25] opacity-0 blur-[4px]",
            )}
          />
        </span>
      </Button>

      <div className="min-w-0 flex-1">
        <div className="mb-1 flex items-center justify-between gap-3">
          <p className="font-body text-[10px] tracking-[0.18em] text-muted uppercase">
            {paused ? "Paused" : "Sim speed"}
          </p>
          <p className="font-mono text-xs tabular-nums text-fg">
            {formatSpeed(speed)}
            <span className="mx-2 text-subtle">·</span>
            Yr {formatYears(years)}
          </p>
        </div>
        <Slider
          min={0}
          max={1}
          step={0.001}
          value={[speedToT(speed)]}
          onValueChange={([t]) => onSpeed(tToSpeed(t ?? 0))}
          aria-label="Simulation speed"
        />
      </div>

      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={onOverview}
        className="hidden h-11 shrink-0 px-3 text-muted sm:inline-flex"
      >
        <RotateCcw />
        <span className="tracking-[0.12em] uppercase">
          {focusedId === "system" ? bodyName : "Overview"}
        </span>
      </Button>
    </div>
  );
}
