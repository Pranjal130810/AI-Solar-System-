export type BodyId =
  | "sun"
  | "mercury"
  | "venus"
  | "earth"
  | "moon"
  | "mars"
  | "jupiter"
  | "saturn"
  | "uranus"
  | "neptune";

export type BodyKind = "star" | "terrestrial" | "gas-giant" | "ice-giant" | "moon";

export type BodyFact = { label: string; value: string };

export type Body = {
  id: BodyId;
  name: string;
  kind: BodyKind;
  parent?: BodyId;
  /** Visual radius in scene units. */
  radius: number;
  /** Orbital radius from parent (or sun) in scene units. */
  distance: number;
  /** Sidereal orbit in Earth years. */
  periodYears: number;
  /** Sidereal spin in Earth days. Negative = retrograde. */
  spinDays: number;
  /** Orbital inclination in radians. */
  inclination: number;
  /** Axial tilt in radians. */
  tilt: number;
  /** Starting true anomaly. */
  phase: number;
  /** Accent used by HUD swatches and orbit trails. */
  swatch: string;
  atmosphere?: string;
  hasRings?: boolean;
  hasClouds?: boolean;
  tagline: string;
  blurb: string;
  facts: BodyFact[];
};

/** Real-time seconds for one Earth revolution at 1×. */
export const EARTH_YEAR_SECONDS = 32;

function orbitSpeed(periodYears: number) {
  return (Math.PI * 2) / (EARTH_YEAR_SECONDS * periodYears);
}

/** Visual spin: keep rotations readable rather than 1:1 with the clock. */
function spinSpeed(spinDays: number) {
  const visualDays = Math.max(Math.abs(spinDays), 0.4);
  const seconds = THREE_DAY_SECONDS * Math.sqrt(visualDays);
  const dir = spinDays < 0 ? -1 : 1;
  return (dir * Math.PI * 2) / seconds;
}

/** One “visual day” baseline at 1×. */
const THREE_DAY_SECONDS = 11;

const DEG = Math.PI / 180;

export const BODIES: Body[] = [
  {
    id: "sun",
    name: "Sun",
    kind: "star",
    radius: 5.1,
    distance: 0,
    periodYears: 0,
    spinDays: 25,
    inclination: 0,
    tilt: 7.25 * DEG,
    phase: 0,
    swatch: "#ffd089",
    tagline: "G-type main-sequence star",
    blurb:
      "The gravitational heart of the system. A 4.6-billion-year furnace of hydrogen fusion that holds every planet on its path and paints the inner worlds with light.",
    facts: [
      { label: "Type", value: "G2V yellow dwarf" },
      { label: "Diameter", value: "1,392,700 km" },
      { label: "Mass", value: "99.86% of the system" },
      { label: "Surface", value: "5,500 °C photosphere" },
      { label: "Age", value: "4.6 billion years" },
    ],
  },
  {
    id: "mercury",
    name: "Mercury",
    kind: "terrestrial",
    radius: 0.38,
    distance: 10.2,
    periodYears: 0.241,
    spinDays: 58.6,
    inclination: 7.0 * DEG,
    tilt: 0.03 * DEG,
    phase: 0.7,
    swatch: "#b7a48a",
    tagline: "Innermost terrestrial",
    blurb:
      "A cratered, airless rock that bakes at noon and freezes at night. Mercury skims the Sun so closely that a year there lasts only 88 Earth days.",
    facts: [
      { label: "Distance", value: "0.39 AU" },
      { label: "Year", value: "88 Earth days" },
      { label: "Day", value: "59 Earth days" },
      { label: "Diameter", value: "4,879 km" },
      { label: "Moons", value: "None" },
    ],
  },
  {
    id: "venus",
    name: "Venus",
    kind: "terrestrial",
    radius: 0.95,
    distance: 14.6,
    periodYears: 0.615,
    spinDays: -243,
    inclination: 3.4 * DEG,
    tilt: 177.4 * DEG,
    phase: 2.1,
    swatch: "#e6d2a8",
    atmosphere: "#efe0b8",
    hasClouds: true,
    tagline: "Veiled twin of Earth",
    blurb:
      "Earth’s size-twin wrapped in a crushing carbon-dioxide shroud. The surface is hotter than Mercury’s, and the planet spins backwards — a day longer than its year.",
    facts: [
      { label: "Distance", value: "0.72 AU" },
      { label: "Year", value: "225 Earth days" },
      { label: "Day", value: "243 Earth days, retrograde" },
      { label: "Diameter", value: "12,104 km" },
      { label: "Atmosphere", value: "96% CO₂, runaway greenhouse" },
    ],
  },
  {
    id: "earth",
    name: "Earth",
    kind: "terrestrial",
    radius: 1,
    distance: 19.4,
    periodYears: 1,
    spinDays: 1,
    inclination: 0,
    tilt: 23.4 * DEG,
    phase: 0.35,
    swatch: "#7eb3e0",
    atmosphere: "#7ec8ff",
    hasClouds: true,
    tagline: "The living world",
    blurb:
      "The only world known to carry oceans of liquid water and a biosphere. A 23-degree tilt gives us seasons; one moon tugs the tides and steadies the axis.",
    facts: [
      { label: "Distance", value: "1.00 AU" },
      { label: "Year", value: "365.25 days" },
      { label: "Day", value: "23 h 56 m" },
      { label: "Diameter", value: "12,742 km" },
      { label: "Moons", value: "1 — Luna" },
    ],
  },
  {
    id: "moon",
    name: "Moon",
    kind: "moon",
    parent: "earth",
    radius: 0.27,
    distance: 2.55,
    periodYears: 0.0748,
    spinDays: 27.3,
    inclination: 5.1 * DEG,
    tilt: 6.7 * DEG,
    phase: 1.4,
    swatch: "#c9c4b8",
    tagline: "Earth’s companion",
    blurb:
      "A tidally locked satellite of anorthosite highlands and dark maria. It is large for a moon — enough to ring Earth with tides and keep our seasons from wandering.",
    facts: [
      { label: "Distance", value: "384,400 km from Earth" },
      { label: "Month", value: "27.3 days" },
      { label: "Day", value: "Tidally locked" },
      { label: "Diameter", value: "3,474 km" },
      { label: "Origin", value: "Giant impact remnant" },
    ],
  },
  {
    id: "mars",
    name: "Mars",
    kind: "terrestrial",
    radius: 0.53,
    distance: 24.6,
    periodYears: 1.881,
    spinDays: 1.03,
    inclination: 1.85 * DEG,
    tilt: 25.2 * DEG,
    phase: 4.2,
    swatch: "#d9896a",
    atmosphere: "#e0a080",
    tagline: "The rusted frontier",
    blurb:
      "A cold desert stained with iron oxide, carved by ancient rivers and crowned with ice. Olympus Mons and Valles Marineris still dwarf anything on Earth.",
    facts: [
      { label: "Distance", value: "1.52 AU" },
      { label: "Year", value: "687 Earth days" },
      { label: "Day", value: "24 h 37 m" },
      { label: "Diameter", value: "6,779 km" },
      { label: "Moons", value: "2 — Phobos & Deimos" },
    ],
  },
  {
    id: "jupiter",
    name: "Jupiter",
    kind: "gas-giant",
    radius: 2.85,
    distance: 38.4,
    periodYears: 11.86,
    spinDays: 0.41,
    inclination: 1.3 * DEG,
    tilt: 3.1 * DEG,
    phase: 5.6,
    swatch: "#d9b48a",
    atmosphere: "#e8c9a0",
    tagline: "King of the giants",
    blurb:
      "A failed star of hydrogen and helium, banded by jet streams and stamped with the Great Red Spot — a storm older than any nation on Earth.",
    facts: [
      { label: "Distance", value: "5.20 AU" },
      { label: "Year", value: "11.9 Earth years" },
      { label: "Day", value: "9 h 56 m" },
      { label: "Diameter", value: "139,820 km" },
      { label: "Moons", value: "95+" },
    ],
  },
  {
    id: "saturn",
    name: "Saturn",
    kind: "gas-giant",
    radius: 2.38,
    distance: 51.2,
    periodYears: 29.46,
    spinDays: 0.45,
    inclination: 2.49 * DEG,
    tilt: 26.7 * DEG,
    phase: 1.1,
    swatch: "#e6d7b0",
    atmosphere: "#f0e4c4",
    hasRings: true,
    tagline: "The ringed giant",
    blurb:
      "A pale gold world so light it would float on water, wearing the solar system’s most famous rings — ice and dust shepherded into knife-thin sheets.",
    facts: [
      { label: "Distance", value: "9.58 AU" },
      { label: "Year", value: "29.5 Earth years" },
      { label: "Day", value: "10 h 33 m" },
      { label: "Diameter", value: "116,460 km" },
      { label: "Rings", value: "Ice-rich, ~280,000 km across" },
    ],
  },
  {
    id: "uranus",
    name: "Uranus",
    kind: "ice-giant",
    radius: 1.52,
    distance: 64.8,
    periodYears: 84.01,
    spinDays: -0.72,
    inclination: 0.77 * DEG,
    tilt: 97.8 * DEG,
    phase: 3.3,
    swatch: "#9fd4d8",
    atmosphere: "#b7ecec",
    tagline: "The sideways ice giant",
    blurb:
      "A pale cyan ball of water, ammonia, and methane ices, knocked onto its side. It rolls around the Sun like a barrel, poles taking turns in decades of daylight.",
    facts: [
      { label: "Distance", value: "19.2 AU" },
      { label: "Year", value: "84 Earth years" },
      { label: "Day", value: "17 h 14 m, retrograde" },
      { label: "Diameter", value: "50,724 km" },
      { label: "Tilt", value: "98° — seasons last 21 years" },
    ],
  },
  {
    id: "neptune",
    name: "Neptune",
    kind: "ice-giant",
    radius: 1.46,
    distance: 77.6,
    periodYears: 164.8,
    spinDays: 0.67,
    inclination: 1.77 * DEG,
    tilt: 28.3 * DEG,
    phase: 0.2,
    swatch: "#5b82d6",
    atmosphere: "#6f9cff",
    tagline: "The outer wind",
    blurb:
      "The last true planet, a deep cobalt ice giant with the fastest winds in the system. It was predicted by mathematics before anyone saw it through a telescope.",
    facts: [
      { label: "Distance", value: "30.1 AU" },
      { label: "Year", value: "165 Earth years" },
      { label: "Day", value: "16 h 6 m" },
      { label: "Diameter", value: "49,244 km" },
      { label: "Winds", value: "Up to 2,000 km/h" },
    ],
  },
];

export const BODY_BY_ID: Record<BodyId, Body> = Object.fromEntries(
  BODIES.map((b) => [b.id, b]),
) as Record<BodyId, Body>;

export const PRIMARY_BODIES = BODIES.filter((b) => b.id !== "moon");

export type FocusId = BodyId | "system";

export function orbitRadiansPerSecond(body: Body) {
  if (body.periodYears <= 0) return 0;
  return orbitSpeed(body.periodYears);
}

export function spinRadiansPerSecond(body: Body) {
  if (body.id === "sun") return (Math.PI * 2) / 80;
  return spinSpeed(body.spinDays);
}

export function kindLabel(kind: BodyKind) {
  switch (kind) {
    case "star":
      return "Star";
    case "terrestrial":
      return "Terrestrial planet";
    case "gas-giant":
      return "Gas giant";
    case "ice-giant":
      return "Ice giant";
    case "moon":
      return "Natural satellite";
  }
}
