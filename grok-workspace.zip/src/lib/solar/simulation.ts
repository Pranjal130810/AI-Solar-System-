import { Vector3 } from "three";
import {
  BODY_BY_ID,
  type BodyId,
  type FocusId,
  orbitRadiansPerSecond,
} from "./bodies";

export const simTime = { current: 0 };

const scratch = new Vector3();

export function tickSim(delta: number, paused: boolean, speed: number) {
  if (!paused) {
    simTime.current += Math.min(delta, 0.1) * speed;
  }
}

function localOrbit(id: BodyId, t: number, out: Vector3) {
  const body = BODY_BY_ID[id];
  const speed = orbitRadiansPerSecond(body);
  const angle = t * speed + body.phase;
  const c = Math.cos(angle) * body.distance;
  const s = Math.sin(angle) * body.distance;
  const inc = body.inclination;
  out.set(c, -s * Math.sin(inc), s * Math.cos(inc));
  return out;
}

export function getBodyPosition(id: FocusId, out: Vector3) {
  if (id === "system" || id === "sun") {
    return out.set(0, 0, 0);
  }
  const body = BODY_BY_ID[id];
  if (body.parent) {
    getBodyPosition(body.parent, out);
    localOrbit(id, simTime.current, scratch);
    return out.add(scratch);
  }
  return localOrbit(id, simTime.current, out);
}

export function cameraOffsetFor(id: FocusId, out: Vector3) {
  if (id === "system") {
    return out.set(0, 46, 108);
  }
  const body = BODY_BY_ID[id];
  if (id === "sun") {
    return out.set(9.5, 5.4, 16.5);
  }
  const dist = Math.min(Math.max(body.radius * 8.4, 3.4), 26);
  return out.set(dist * 0.62, dist * 0.36, dist * 0.95);
}
