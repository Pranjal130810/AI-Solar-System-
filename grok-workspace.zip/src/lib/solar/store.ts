import { create } from "zustand";
import type { FocusId } from "./bodies";

export const SPEED_MIN = 0.25;
export const SPEED_MAX = 24;

type SolarState = {
  paused: boolean;
  speed: number;
  focusedId: FocusId;
  showLabels: boolean;
  showTrails: boolean;
  years: number;
  setPaused: (paused: boolean) => void;
  togglePaused: () => void;
  setSpeed: (speed: number) => void;
  setFocused: (id: FocusId) => void;
  toggleLabels: () => void;
  toggleTrails: () => void;
  setYears: (years: number) => void;
};

export const useSolarStore = create<SolarState>()((set) => ({
  paused: false,
  speed: 1,
  focusedId: "system",
  showLabels: true,
  showTrails: true,
  years: 0,
  setPaused: (paused) => set({ paused }),
  togglePaused: () => set((s) => ({ paused: !s.paused })),
  setSpeed: (speed) =>
    set({ speed: Math.min(SPEED_MAX, Math.max(SPEED_MIN, speed)) }),
  setFocused: (focusedId) => set({ focusedId }),
  toggleLabels: () => set((s) => ({ showLabels: !s.showLabels })),
  toggleTrails: () => set((s) => ({ showTrails: !s.showTrails })),
  setYears: (years) => set({ years }),
}));
