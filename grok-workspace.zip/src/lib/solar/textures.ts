import {
  CanvasTexture,
  LinearFilter,
  LinearMipmapLinearFilter,
  RepeatWrapping,
  SRGBColorSpace,
  NoColorSpace,
  type Texture,
} from "three";
import type { BodyId } from "./bodies";

function hash(x: number, y: number, z: number) {
  let n = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(z | 0, 1274126177);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function noise3(x: number, y: number, z: number) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fy = y - iy;
  const fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const uz = fz * fz * (3 - 2 * fz);
  const n000 = hash(ix, iy, iz);
  const n100 = hash(ix + 1, iy, iz);
  const n010 = hash(ix, iy + 1, iz);
  const n110 = hash(ix + 1, iy + 1, iz);
  const n001 = hash(ix, iy, iz + 1);
  const n101 = hash(ix + 1, iy, iz + 1);
  const n011 = hash(ix, iy + 1, iz + 1);
  const n111 = hash(ix + 1, iy + 1, iz + 1);
  const nx00 = n000 + (n100 - n000) * ux;
  const nx10 = n010 + (n110 - n010) * ux;
  const nx01 = n001 + (n101 - n001) * ux;
  const nx11 = n011 + (n111 - n011) * ux;
  const nxy0 = nx00 + (nx10 - nx00) * uy;
  const nxy1 = nx01 + (nx11 - nx01) * uy;
  return nxy0 + (nxy1 - nxy0) * uz;
}

function fbm(
  x: number,
  y: number,
  z: number,
  octaves: number,
  lacunarity = 2,
  gain = 0.5,
) {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  const n = Math.min(octaves, 4);
  for (let i = 0; i < n; i++) {
    sum += amp * noise3(x * freq, y * freq, z * freq);
    norm += amp;
    freq *= lacunarity;
    amp *= gain;
  }
  return sum / norm;
}

function spherePoint(u: number, v: number) {
  const lon = u * Math.PI * 2;
  const lat = v * Math.PI;
  const sl = Math.sin(lat);
  return {
    x: sl * Math.cos(lon),
    y: Math.cos(lat),
    z: sl * Math.sin(lon),
    lat,
    lon,
  };
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function clamp(v: number, lo = 0, hi = 1) {
  return Math.min(hi, Math.max(lo, v));
}

function mixRgb(
  a: [number, number, number],
  b: [number, number, number],
  t: number,
): [number, number, number] {
  return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
}

function paint(
  width: number,
  height: number,
  pixel: (
    u: number,
    v: number,
    p: ReturnType<typeof spherePoint>,
  ) => [number, number, number, number],
  colorSpace: typeof SRGBColorSpace | typeof NoColorSpace = SRGBColorSpace,
) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas 2D unavailable");
  const img = ctx.createImageData(width, height);
  const data = img.data;
  for (let y = 0; y < height; y++) {
    const v = (y + 0.5) / height;
    for (let x = 0; x < width; x++) {
      const u = (x + 0.5) / width;
      const p = spherePoint(u, v);
      const [r, g, b, a] = pixel(u, v, p);
      const i = (y * width + x) * 4;
      data[i] = r;
      data[i + 1] = g;
      data[i + 2] = b;
      data[i + 3] = a;
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new CanvasTexture(canvas);
  tex.colorSpace = colorSpace;
  tex.wrapS = RepeatWrapping;
  tex.wrapT = RepeatWrapping;
  tex.minFilter = LinearMipmapLinearFilter;
  tex.magFilter = LinearFilter;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

function crateredRock(
  p: ReturnType<typeof spherePoint>,
  seed: number,
): number {
  const n = fbm(p.x * 3 + seed, p.y * 3, p.z * 3, 6);
  const pits = fbm(p.x * 9 + seed, p.y * 9, p.z * 9, 3);
  const craters = Math.pow(clamp(1 - Math.abs(pits - 0.42) * 8), 3);
  return clamp(n * 0.85 - craters * 0.28);
}

function mercuryPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const h = crateredRock(p, 2.1);
  const c = mixRgb([78, 68, 58], [186, 168, 146], h);
  const dark = mixRgb(c, [42, 38, 34], clamp((0.35 - h) * 1.8));
  return [dark[0], dark[1], dark[2], 255];
}

function venusPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const swirl =
    fbm(p.x * 2.2 + p.y * 0.4, p.y * 3.4, p.z * 2.2 - p.y * 0.6, 5);
  const bands = 0.5 + 0.5 * Math.sin(p.y * 9 + swirl * 4);
  const c = mixRgb([214, 186, 132], [244, 228, 196], bands);
  const shade = mixRgb(c, [168, 132, 92], clamp(swirl * 0.35));
  return [shade[0], shade[1], shade[2], 255];
}

function earthPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const warped = fbm(p.x * 1.6, p.y * 1.6, p.z * 1.6, 3);
  const n = fbm(
    p.x * 2.4 + warped * 0.55,
    p.y * 2.6,
    p.z * 2.4 - warped * 0.4,
    6,
  );
  const land = n > 0.52;
  const ice =
    Math.abs(p.y) > 0.86 || (Math.abs(p.y) > 0.72 && n > 0.48);
  let c: [number, number, number];
  if (ice) {
    c = mixRgb([226, 236, 245], [248, 252, 255], n);
  } else if (land) {
    const arid = fbm(p.x * 5, p.y * 5, p.z * 5, 3);
    c = mixRgb([46, 92, 54], [142, 124, 72], clamp(arid * 1.2 - 0.2));
    if (n > 0.64) c = mixRgb(c, [92, 78, 58], 0.55);
  } else {
    const deep = clamp((0.52 - n) * 3);
    c = mixRgb([28, 92, 148], [8, 32, 72], deep);
  }
  return [c[0], c[1], c[2], 255];
}

function marsPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const n = fbm(p.x * 3.1, p.y * 3.1, p.z * 3.1, 6);
  const rift = Math.pow(clamp(1 - Math.abs(p.y + 0.08 - n * 0.2) * 7), 2);
  let c = mixRgb([96, 42, 28], [196, 110, 72], n);
  c = mixRgb(c, [58, 36, 28], rift * 0.65);
  if (Math.abs(p.y) > 0.82) {
    c = mixRgb(c, [236, 240, 244], clamp((Math.abs(p.y) - 0.82) * 8));
  }
  return [c[0], c[1], c[2], 255];
}

function jupiterPixel(
  u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const turb = fbm(p.x * 2.2, p.y * 6, p.z * 2.2, 5);
  const bands = 0.5 + 0.5 * Math.sin(p.y * 18 + turb * 3.4);
  const palette: [number, number, number][] = [
    [214, 186, 142],
    [168, 122, 78],
    [236, 214, 176],
    [124, 86, 58],
    [228, 196, 150],
  ];
  const idx = Math.floor(clamp(bands) * (palette.length - 0.01));
  const next = Math.min(idx + 1, palette.length - 1);
  let c = mixRgb(palette[idx]!, palette[next]!, bands * 4 - idx);
  const dx = Math.abs(((u + 0.18) % 1) - 0.5);
  const dy = p.y + 0.22;
  const spot = Math.exp(-(dx * dx * 90 + dy * dy * 220));
  c = mixRgb(c, [176, 72, 48], spot);
  return [c[0], c[1], c[2], 255];
}

function saturnPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const turb = fbm(p.x * 1.6, p.y * 5.2, p.z * 1.6, 4);
  const bands = 0.5 + 0.5 * Math.sin(p.y * 14 + turb * 2.2);
  const c = mixRgb([214, 196, 150], [236, 224, 192], bands);
  const shade = mixRgb(c, [168, 148, 110], clamp(turb * 0.4));
  return [shade[0], shade[1], shade[2], 255];
}

function uranusPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const n = fbm(p.x * 2, p.y * 2.8, p.z * 2, 4);
  const c = mixRgb([146, 204, 208], [188, 232, 228], n);
  return [c[0], c[1], c[2], 255];
}

function neptunePixel(
  u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const turb = fbm(p.x * 2.4, p.y * 4.2, p.z * 2.4, 5);
  const bands = 0.5 + 0.5 * Math.sin(p.y * 10 + turb * 2);
  let c = mixRgb([42, 74, 168], [96, 140, 214], bands);
  const dx = Math.abs(((u + 0.62) % 1) - 0.5);
  const dy = p.y - 0.18;
  const spot = Math.exp(-(dx * dx * 70 + dy * dy * 180));
  c = mixRgb(c, [18, 28, 72], spot * 0.85);
  return [c[0], c[1], c[2], 255];
}

function moonPixel(
  _u: number,
  _v: number,
  p: ReturnType<typeof spherePoint>,
): [number, number, number, number] {
  const h = crateredRock(p, 8.4);
  const maria = fbm(p.x * 1.8 + 4, p.y * 1.8, p.z * 1.8, 4);
  let c = mixRgb([118, 114, 108], [210, 204, 194], h);
  if (maria < 0.42 && p.x > -0.2) {
    c = mixRgb(c, [72, 74, 80], 0.55);
  }
  return [c[0], c[1], c[2], 255];
}

const COLOR_FN: Record<Exclude<BodyId, "sun">, typeof earthPixel> = {
  mercury: mercuryPixel,
  venus: venusPixel,
  earth: earthPixel,
  moon: moonPixel,
  mars: marsPixel,
  jupiter: jupiterPixel,
  saturn: saturnPixel,
  uranus: uranusPixel,
  neptune: neptunePixel,
};

function bumpFromColor(id: Exclude<BodyId, "sun">) {
  return paint(
    256,
    128,
    (u, v, p) => {
      const [r, g, b] = COLOR_FN[id](u, v, p);
      const lum = (r * 0.35 + g * 0.45 + b * 0.2) | 0;
      return [lum, lum, lum, 255];
    },
    NoColorSpace,
  );
}

function earthClouds() {
  return paint(512, 256, (_u, _v, p) => {
    const n = fbm(p.x * 3.4, p.y * 4.2, p.z * 3.4, 4);
    const streaks = fbm(p.x * 6, p.y * 1.4, p.z * 6, 3);
    const a = clamp((n - 0.52) * 3.4 + streaks * 0.15) * 220;
    return [244, 248, 252, a];
  });
}

function venusClouds() {
  return paint(512, 256, (_u, _v, p) => {
    const swirl = fbm(p.x * 1.8 + p.y * 0.8, p.y * 4, p.z * 1.8, 4);
    const a = 200 + swirl * 40;
    const c = mixRgb([236, 214, 170], [250, 240, 214], swirl);
    return [c[0], c[1], c[2], a];
  });
}

export function makeRingTexture() {
  const size = 512;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D unavailable");
  const img = ctx.createImageData(size, size);
  const data = img.data;
  const inner = 1.28 / 2.18;
  for (let y = 0; y < size; y++) {
    const ny = (y / (size - 1)) * 2 - 1;
    for (let x = 0; x < size; x++) {
      const nx = (x / (size - 1)) * 2 - 1;
      const r = Math.sqrt(nx * nx + ny * ny);
      const i = (y * size + x) * 4;
      if (r < inner || r > 1) {
        data[i + 3] = 0;
        continue;
      }
      const t = (r - inner) / (1 - inner);
      let alpha = 0;
      if (t < 0.04 || t > 0.98) alpha = 12;
      else if (t > 0.44 && t < 0.54) alpha = 10;
      else {
        const grain = hash(r * 80, nx * 12, ny * 12);
        const band = 0.45 + 0.55 * Math.sin(t * 70);
        alpha = (100 + band * 120 + grain * 40) * (t > 0.54 ? 0.72 : 1);
      }
      const col = mixRgb([214, 196, 160], [246, 236, 210], t);
      data[i] = col[0];
      data[i + 1] = col[1];
      data[i + 2] = col[2];
      data[i + 3] = clamp(alpha, 0, 255);
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new CanvasTexture(canvas);
  tex.colorSpace = SRGBColorSpace;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

export function makeHaloTexture() {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D unavailable");
  const g = ctx.createRadialGradient(
    size / 2,
    size / 2,
    4,
    size / 2,
    size / 2,
    size / 2,
  );
  g.addColorStop(0, "rgba(255, 248, 230, 1)");
  g.addColorStop(0.12, "rgba(255, 210, 120, 0.55)");
  g.addColorStop(0.32, "rgba(255, 150, 50, 0.18)");
  g.addColorStop(0.6, "rgba(255, 90, 20, 0.05)");
  g.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new CanvasTexture(canvas);
  tex.colorSpace = SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export type PlanetMaps = {
  map: Texture;
  bump: Texture;
  clouds?: Texture;
};

const cache = new Map<BodyId, PlanetMaps>();
let ringTex: Texture | null = null;
let haloTex: Texture | null = null;

export function getPlanetMaps(id: Exclude<BodyId, "sun">): PlanetMaps {
  const hit = cache.get(id);
  if (hit) return hit;
  const w = id === "earth" || id === "jupiter" ? 512 : 384;
  const h = w / 2;
  const map = paint(w, h, COLOR_FN[id]);
  const bump = bumpFromColor(id);
  const clouds =
    id === "earth" ? earthClouds() : id === "venus" ? venusClouds() : undefined;
  const set: PlanetMaps = { map, bump, clouds };
  cache.set(id, set);
  return set;
}

export function getRingTexture() {
  ringTex ??= makeRingTexture();
  return ringTex;
}

export function getHaloTexture() {
  haloTex ??= makeHaloTexture();
  return haloTex;
}

export function disposeTextures() {
  for (const set of cache.values()) {
    set.map.dispose();
    set.bump.dispose();
    set.clouds?.dispose();
  }
  cache.clear();
  ringTex?.dispose();
  haloTex?.dispose();
  ringTex = null;
  haloTex = null;
}
